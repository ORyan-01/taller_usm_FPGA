# ============================================================================
# crear_proyecto.tcl - Crea un proyecto de Vivado con todo el kit, listo para simular.
#
# Uso: en Vivado, consola Tcl (pestana "Tcl Console", abajo), escribe:
#     source C:/fpga/taller-dsp-fpga/extras/kit_practica/crear_proyecto.tcl
# (cambia la ruta por la tuya; usa / y evita espacios y tildes en la ruta)
#
# Para simular otro testbench, en la misma consola:
#     close_sim
#     set_property top tb_blinky [get_filesets sim_1]
#     launch_simulation
# ============================================================================

# Parte (chip) de la Basys 3. Para SIMULAR da lo mismo; para la placa usa la tuya:
#   Nexys A7-100T: xc7a100tcsg324-1   Arty A7-35T: xc7a35ticsg324-1L
#   PYNQ-Z2 / Zybo Z7-20: xc7z020clg400-1   Zybo Z7-10: xc7z010clg400-1
set PART xc7a35tcpg236-1

set here [file normalize [file dirname [info script]]]
cd $here
create_project kit_dsp ./vivado_kit -part $PART -force

# Fuentes de diseno (lo que se sintetiza) + archivos que inicializan memorias
add_files -fileset sources_1 -norecurse [list \
    00_blinky/blinky.v \
    01_fir/fir_transposed.v \
    02_nco/nco.v \
    03_top/dsp_top.v \
    01_fir/coefs.mem \
    02_nco/sine_lut.mem ]

# Fuentes de simulacion: testbenches + datos de prueba
add_files -fileset sim_1 -norecurse [list \
    00_blinky/tb_blinky.v \
    01_fir/tb_fir.v \
    03_top/tb_dsp_top.v \
    01_fir/x_in.mem \
    01_fir/y_expected.mem ]

# Pines: solo validos para una Basys 3 (si tu placa es otra, reemplaza este archivo)
add_files -fileset constrs_1 -norecurse 03_top/basys3_dsp_top.xdc

set_property top dsp_top [get_filesets sources_1]
set_property top tb_fir  [get_filesets sim_1]
# Vivado simula 1000 ns por defecto; los testbenches terminan solos con $finish
set_property -name {xsim.simulate.runtime} -value {3ms} -objects [get_filesets sim_1]
update_compile_order -fileset sources_1
update_compile_order -fileset sim_1

puts "Proyecto creado en $here/vivado_kit"
puts "Siguiente paso: Flow Navigator > SIMULATION > Run Behavioral Simulation (debe imprimir PASS)"
