// ============================================================================
// fir_transposed.v - Filtro FIR en forma transpuesta, punto fijo con signo.
//
//      y[n] = sum_{k=0}^{NTAPS-1} h[k] * x[n-k]
//
// Formato Q1.15 (por defecto): un entero con signo de 16 bits que representa
//      valor_real = entero / 2^15        rango [-1, 1)
//
// Por que forma transpuesta: la muestra x llega a TODOS los multiplicadores a
// la vez y cada etapa hace  acc[k] <= acc[k+1] + x*h[k].  Eso calza exacto con
// un bloque DSP48 (multiplicador + sumador + registro) y el camino critico es
// un multiplicador + un sumador, sin importar cuantos taps tenga el filtro.
//
// Interfaz: in_valid = 1 durante un ciclo por cada muestra nueva.
// Latencia: 3 ciclos de reloj desde in_valid hasta out_valid.
// ============================================================================
`timescale 1ns / 1ps

module fir_transposed #(
    parameter integer NTAPS     = 31,
    parameter integer DATA_W    = 16,          // ancho de la muestra de entrada
    parameter integer COEF_W    = 16,          // ancho de cada coeficiente
    parameter integer COEF_FRAC = 15,          // bits fraccionarios de los coeficientes (Q1.15)
    parameter integer OUT_W     = 16,          // ancho de la salida
    parameter         COEF_FILE = "coefs.mem"  // coeficientes en hex, uno por linea
) (
    input  wire                     clk,
    input  wire                     rst,       // sincrono, activo en alto
    input  wire                     in_valid,  // 1 = hay muestra nueva en in_data
    input  wire signed [DATA_W-1:0] in_data,
    output reg                      out_valid,
    output reg  signed [OUT_W-1:0]  out_data
);
    // Crecimiento de bits: un producto ocupa DATA_W + COEF_W bits y sumar NTAPS
    // productos agrega hasta ceil(log2(NTAPS)) bits. Asi el acumulador nunca desborda.
    localparam integer ACC_W = DATA_W + COEF_W + $clog2(NTAPS);

    // ---------------- coeficientes: ROM inicializada desde archivo ----------------
    reg signed [COEF_W-1:0] coef [0:NTAPS-1];
    initial $readmemh(COEF_FILE, coef);

    // ---------------- etapa 0: registrar la entrada ----------------
    reg signed [DATA_W-1:0] x_r;
    reg                     v0;
    always @(posedge clk) begin
        if (rst) begin
            x_r <= 0;
            v0  <= 1'b0;
        end else begin
            v0 <= in_valid;
            if (in_valid) x_r <= in_data;
        end
    end

    // ---------------- etapa 1: cadena transpuesta de MACs ----------------
    reg signed [ACC_W-1:0] acc [0:NTAPS-1];
    reg                    v1;
    integer k;
    always @(posedge clk) begin
        if (rst) begin
            for (k = 0; k < NTAPS; k = k + 1) acc[k] <= 0;
            v1 <= 1'b0;
        end else begin
            v1 <= v0;
            if (v0) begin
                // OJO: x_r y coef son "signed" y la operacion se calcula con el ancho
                // del lado izquierdo (ACC_W bits). Si un solo operando fuera unsigned,
                // TODA la expresion seria unsigned y los negativos saldrian mal.
                acc[NTAPS-1] <= x_r * coef[NTAPS-1];
                for (k = 0; k < NTAPS-1; k = k + 1)
                    acc[k] <= acc[k+1] + x_r * coef[k];
            end
        end
    end

    // ---------------- etapa 2: redondeo + saturacion a OUT_W bits ----------------
    // Volver a Q1.15: sumar medio LSB y desplazar COEF_FRAC bits a la derecha.
    // >>> es desplazamiento aritmetico: conserva el signo (>> rellenaria con ceros).
    localparam signed [ACC_W-1:0] HALF_LSB = 1 <<< (COEF_FRAC - 1);
    localparam signed [ACC_W-1:0] OUT_MAX  =  (2 ** (OUT_W - 1)) - 1;
    localparam signed [ACC_W-1:0] OUT_MIN  = -(2 ** (OUT_W - 1));

    wire signed [ACC_W-1:0] acc_rnd = (acc[0] + HALF_LSB) >>> COEF_FRAC;

    always @(posedge clk) begin
        if (rst) begin
            out_valid <= 1'b0;
            out_data  <= 0;
        end else begin
            out_valid <= v1;
            if (v1) begin
                if      (acc_rnd > OUT_MAX) out_data <= OUT_MAX[OUT_W-1:0];  // satura arriba
                else if (acc_rnd < OUT_MIN) out_data <= OUT_MIN[OUT_W-1:0];  // satura abajo
                else                        out_data <= acc_rnd[OUT_W-1:0];
            end
        end
    end
endmodule
