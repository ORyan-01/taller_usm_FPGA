// ============================================================================
// tb_fir.v - Testbench AUTOVERIFICABLE para fir_transposed.
//
//  1. Lee la entrada (x_in.mem) y la salida esperada (y_expected.mem), ambas
//     generadas por fir_design.py: el "modelo de oro" en Python, bit a bit.
//  2. Entrega una muestra cada GAP+1 ciclos, como en un sistema real donde la
//     tasa de muestreo es menor que la frecuencia del reloj.
//  3. Compara cada salida del filtro con la esperada e imprime PASS o FAIL.
//
//  En Vivado: fir_transposed.v y coefs.mem como Design Sources; este archivo,
//  x_in.mem y y_expected.mem como Simulation Sources. Si los .mem no estan en
//  el proyecto, la simulacion no los encuentra y todo queda en X.
// ============================================================================
`timescale 1ns / 1ps

module tb_fir;
    parameter integer NTAPS    = 31;
    parameter integer NSAMPLES = 400;   // debe calzar con fir_design.py
    parameter integer GAP      = 3;     // ciclos sin dato entre muestras (0 = una por ciclo)

    reg                clk      = 1'b0;
    reg                rst      = 1'b1;
    reg                in_valid = 1'b0;
    reg  signed [15:0] in_data  = 0;
    wire               out_valid;
    wire signed [15:0] out_data;

    fir_transposed #(.NTAPS(NTAPS), .COEF_FILE("coefs.mem")) dut (
        .clk       (clk),
        .rst       (rst),
        .in_valid  (in_valid),
        .in_data   (in_data),
        .out_valid (out_valid),
        .out_data  (out_data)
    );

    always #5 clk = ~clk;   // 10 ns -> 100 MHz

    reg signed [15:0] x_mem [0:NSAMPLES-1];
    reg signed [15:0] y_exp [0:NSAMPLES-1];
    integer i;
    integer n_out   = 0;
    integer errores = 0;

    // ---- verificador: compara cada salida valida con la esperada ----
    always @(posedge clk) begin
        if (out_valid) begin
            if (out_data !== y_exp[n_out]) begin
                errores = errores + 1;
                if (errores <= 10)
                    $display("ERROR muestra %0d: obtuve %0d, esperaba %0d",
                             n_out, out_data, y_exp[n_out]);
            end
            n_out = n_out + 1;
        end
    end

    // ---- estimulo ----
    initial begin
        $readmemh("x_in.mem", x_mem);
        $readmemh("y_expected.mem", y_exp);
        #1;
        // Diagnostico del error mas comun: los archivos .mem no se encontraron
        if ((^dut.coef[0] === 1'bx) || (^x_mem[0] === 1'bx) || (^y_exp[0] === 1'bx)) begin
            $display("ERROR: algun archivo .mem no se cargo (quedo en X).");
            $display("       Agrega coefs.mem, x_in.mem y y_expected.mem al proyecto,");
            $display("       o escribe la ruta completa con / (ej: C:/fpga/kit/01_fir/coefs.mem).");
            $finish;
        end

        repeat (4) @(posedge clk);
        rst <= 1'b0;

        for (i = 0; i < NSAMPLES; i = i + 1) begin
            in_valid <= 1'b1;
            in_data  <= x_mem[i];
            @(posedge clk);
            if (GAP > 0) begin
                in_valid <= 1'b0;
                repeat (GAP) @(posedge clk);
            end
        end
        in_valid <= 1'b0;

        repeat (10) @(posedge clk);   // vaciar el pipeline

        if (errores == 0 && n_out == NSAMPLES)
            $display("PASS: %0d muestras identicas al modelo de Python", n_out);
        else
            $display("FAIL: %0d errores, %0d salidas (esperaba %0d)", errores, n_out, NSAMPLES);
        $finish;
    end
endmodule
