"""
fir_design.py - Disena el FIR, lo cuantiza a punto fijo y genera los archivos
que usa el testbench. Es el "modelo de oro": calcula, bit a bit, lo mismo que
debe calcular el hardware.

Uso:   python fir_design.py        (pip install numpy scipy matplotlib)

Genera:
  coefs.mem          coeficientes Q1.15 en hex, uno por linea ($readmemh)
  coefs.coe          los mismos coeficientes para el IP "FIR Compiler" de Vivado
  x_in.mem           entrada de prueba: tono de 20 kHz + tono de 300 kHz
  y_expected.mem     salida exacta que debe producir fir_transposed.v
  fir_resultado.png  (si hay matplotlib) respuesta en frecuencia y senales

Si cambias NTAPS o NSAMPLES, cambia tambien los parametros del testbench.
"""
import numpy as np
from scipy import signal

FS = 1_000_000          # frecuencia de muestreo [Hz]
FC = 100_000            # frecuencia de corte del pasabajos [Hz]
NTAPS = 31              # numero de coeficientes (taps)
FRAC = 15               # formato Q1.15: 15 bits fraccionarios
NSAMPLES = 400          # largo de la senal de prueba
F_PASA, F_RECHAZA = 20_000, 300_000   # un tono que pasa y uno que se elimina

QMIN, QMAX = -2**15, 2**15 - 1


def a_q15(v):
    """Real -> entero Q1.15 con redondeo y saturacion."""
    return np.clip(np.round(np.asarray(v) * 2**FRAC), QMIN, QMAX).astype(np.int64)


def hex16(v):
    """Entero con signo -> 4 digitos hex en complemento a 2 (ej: -5 -> FFFB)."""
    return f"{int(v) & 0xFFFF:04X}"


def escribir_mem(nombre, valores):
    with open(nombre, "w") as f:
        f.write("\n".join(hex16(v) for v in valores) + "\n")


# 1) Diseno en punto flotante (ventana de Hamming, ganancia 1 en DC)
h = signal.firwin(NTAPS, FC, fs=FS)

# 2) Cuantizacion de los coeficientes
h_q = a_q15(h)

# 3) Senal de prueba: suma de dos tonos (amplitud 0.45 cada uno, no satura)
n = np.arange(NSAMPLES)
x = 0.45 * np.sin(2 * np.pi * F_PASA * n / FS) + 0.45 * np.sin(2 * np.pi * F_RECHAZA * n / FS)
x_q = a_q15(x)

# 4) Modelo de oro: exactamente lo que hace el hardware
acc = np.convolve(x_q, h_q)[:NSAMPLES]          # sumas de productos con enteros exactos
y_q = (acc + (1 << (FRAC - 1))) >> FRAC          # redondeo + desplazamiento aritmetico
y_q = np.clip(y_q, QMIN, QMAX)                   # saturacion a 16 bits

# 5) Archivos para Verilog y para el IP de Vivado
escribir_mem("coefs.mem", h_q)
escribir_mem("x_in.mem", x_q)
escribir_mem("y_expected.mem", y_q)
with open("coefs.coe", "w") as f:
    f.write("radix = 10;\ncoefdata =\n")
    f.write(",\n".join(str(int(v)) for v in h_q) + ";\n")

# 6) Resumen
w, H = signal.freqz(h_q / 2**FRAC, worN=4096, fs=FS)
def ganancia_db(f):
    return 20 * np.log10(abs(H[np.argmin(abs(w - f))]) + 1e-12)
print(f"Taps: {NTAPS}   suma de coeficientes: {h_q.sum()} (32768 = ganancia 1 en DC)")
print(f"Ganancia a {F_PASA/1e3:.0f} kHz: {ganancia_db(F_PASA):6.2f} dB")
print(f"Ganancia a {F_RECHAZA/1e3:.0f} kHz: {ganancia_db(F_RECHAZA):6.2f} dB")
print("Archivos: coefs.mem, coefs.coe, x_in.mem, y_expected.mem")

# 7) Grafico opcional
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except ImportError:
    print("(sin matplotlib: no se genera el grafico)")
else:
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(9, 7))
    wf, Hf = signal.freqz(h, worN=4096, fs=FS)
    a1.plot(wf / 1e3, 20 * np.log10(abs(Hf) + 1e-12), label="coeficientes reales")
    a1.plot(w / 1e3, 20 * np.log10(abs(H) + 1e-12), "--", label="cuantizados Q1.15")
    for f0 in (F_PASA, F_RECHAZA):
        a1.axvline(f0 / 1e3, color="gray", lw=0.8, ls=":")
    a1.set_xlabel("frecuencia [kHz]"); a1.set_ylabel("ganancia [dB]")
    a1.set_ylim(-90, 5); a1.grid(True, alpha=0.3); a1.legend()
    a1.set_title(f"FIR pasabajos, {NTAPS} taps, corte {FC/1e3:.0f} kHz, fs = {FS/1e6:.0f} MHz")
    t_us = n / FS * 1e6
    a2.plot(t_us, x_q / 2**FRAC, lw=0.8, label="entrada x (20 kHz + 300 kHz)")
    a2.plot(t_us, y_q / 2**FRAC, lw=1.8, label="salida y (solo queda 20 kHz)")
    a2.set_xlabel("tiempo [us]"); a2.set_ylabel("amplitud"); a2.grid(True, alpha=0.3)
    a2.legend(loc="upper right")
    fig.tight_layout()
    fig.savefig("fir_resultado.png", dpi=120)
    print("Grafico: fir_resultado.png")
