## basys3_blinky.xdc - Pines para blinky.v en una Digilent Basys 3 (xc7a35tcpg236-1).
## Si tu placa es otra, copia las lineas equivalentes del "Master XDC" oficial de tu placa
## (Digilent los publica en github.com/Digilent/digilent-xdc) y cambia solo los nombres de puerto.

## Reloj de 100 MHz
set_property -dict { PACKAGE_PIN W5  IOSTANDARD LVCMOS33 } [get_ports clk]
create_clock -add -name sys_clk_pin -period 10.00 -waveform {0 5} [get_ports clk]

## Boton central como reset
set_property -dict { PACKAGE_PIN U18 IOSTANDARD LVCMOS33 } [get_ports rst]

## LED 0
set_property -dict { PACKAGE_PIN U16 IOSTANDARD LVCMOS33 } [get_ports led]

## Configuracion (evita advertencias de DRC en la Basys 3)
set_property CONFIG_VOLTAGE 3.3 [current_design]
set_property CFGBVS VCCO [current_design]
