// ============================================================================
// blinky.v - "hola mundo" de FPGA: un contador hace parpadear un LED.
//
// Que practicas aqui:
//   * modulo, parametros y puertos
//   * logica secuencial: always @(posedge clk) con asignaciones no bloqueantes (<=)
//   * reset sincrono (el estilo recomendado en FPGAs AMD/Xilinx)
//   * $clog2 para calcular cuantos bits necesita un contador
// ============================================================================
`timescale 1ns / 1ps

module blinky #(
    parameter integer CLK_HZ   = 100_000_000, // reloj de la placa (Basys 3 / Nexys A7 / Arty A7: 100 MHz)
    parameter integer BLINK_HZ = 1            // periodos completos de parpadeo por segundo
) (
    input  wire clk,
    input  wire rst,   // reset sincrono, activo en alto (un boton)
    output reg  led
);
    // El LED cambia de estado cada medio periodo: CLK_HZ / (2*BLINK_HZ) ciclos
    localparam integer HALF = CLK_HZ / (2 * BLINK_HZ);
    localparam integer W    = $clog2(HALF);   // bits justos para contar de 0 a HALF-1

    reg [W-1:0] cnt;

    always @(posedge clk) begin
        if (rst) begin
            cnt <= 0;
            led <= 1'b0;
        end else if (cnt == HALF - 1) begin
            cnt <= 0;
            led <= ~led;
        end else begin
            cnt <= cnt + 1'b1;
        end
    end
endmodule
