// ============================================================================
// tb_blinky.v - Testbench autoverificable para blinky.
//
// Un testbench NO es hardware: es un programa que genera el reloj, mueve las
// entradas y revisa las salidas. Aqui se puede usar #retardos, $display, etc.
//
// En Vivado: Run Behavioral Simulation y despues "Run All" (o escribe  run all
// en la consola Tcl). Por defecto Vivado simula solo 1000 ns.
// ============================================================================
`timescale 1ns / 1ps

module tb_blinky;
    // Parametros chicos para que la simulacion sea corta:
    // "reloj de 1 kHz" y LED a 100 Hz  ->  el LED cambia cada 5 ciclos.
    localparam integer CLK_HZ   = 1000;
    localparam integer BLINK_HZ = 100;
    localparam integer HALF     = CLK_HZ / (2 * BLINK_HZ);
    localparam integer T_CLK    = 10;              // periodo del reloj simulado [ns]

    reg  clk = 1'b0;
    reg  rst = 1'b1;
    wire led;

    // Instancia del diseno bajo prueba (DUT), sobreescribiendo sus parametros
    blinky #(.CLK_HZ(CLK_HZ), .BLINK_HZ(BLINK_HZ)) dut (
        .clk (clk),
        .rst (rst),
        .led (led)
    );

    always #(T_CLK/2) clk = ~clk;   // reloj: se invierte cada medio periodo

    // ---- verificador: mide el tiempo entre cambios del LED ----
    time    t_prev  = 0;
    integer cambios = 0;
    integer errores = 0;

    always @(led) begin
        if (!rst) begin
            if (cambios > 0 && ($time - t_prev) != HALF * T_CLK) begin
                errores = errores + 1;
                $display("ERROR t=%0t ns: el LED cambio tras %0t ns (esperaba %0d ns)",
                         $time, $time - t_prev, HALF * T_CLK);
            end
            t_prev  = $time;
            cambios = cambios + 1;
        end
    end

    // ---- estimulo ----
    initial begin
        $display("Simulando blinky: el LED deberia cambiar cada %0d ciclos", HALF);
        repeat (3) @(posedge clk);
        rst <= 1'b0;                      // <= en el testbench: evita carreras con el DUT
        repeat (20 * HALF) @(posedge clk);

        if (cambios < 15) begin
            errores = errores + 1;
            $display("ERROR: el LED cambio solo %0d veces", cambios);
        end
        if (errores == 0) $display("PASS: %0d cambios del LED, todos cada %0d ciclos", cambios, HALF);
        else              $display("FAIL: %0d errores", errores);
        $finish;
    end
endmodule
