# Kit de práctica — Taller de DSP con FPGA

Cada ejercicio trae un testbench que se revisa solo e imprime `PASS` o `FAIL`.
Todo se probó en simulación con Icarus Verilog 12 (no en Vivado).

## Orden sugerido

1. **00_blinky** — el "hola mundo": un LED que parpadea. Crea TÚ el proyecto en
   Vivado a mano (pasos en la guía, sección "Vivado paso a paso").
2. **01_fir** — filtro FIR de 31 taps en punto fijo Q1.15 + testbench que compara
   cada salida con el modelo de oro en Python (`fir_design.py`).
3. **02_nco + 03_top** — cadena completa: dos osciladores (20 kHz y 300 kHz) →
   suma → FIR → medidor de nivel en 8 LEDs. En simulación, mira `x_mix` e `y_filt`
   en estilo Analog; en la placa, con el switch 0 ves el nivel antes y después del filtro.

## Atajo: el proyecto de Vivado con un comando

Pon el repositorio en una ruta sin espacios ni tildes (ej: `C:/fpga/taller-dsp-fpga`).
En la consola Tcl de Vivado (abajo en la ventana):

    source C:/fpga/taller-dsp-fpga/extras/kit_practica/crear_proyecto.tcl

Luego: Flow Navigator → SIMULATION → Run Behavioral Simulation. Debe aparecer
`PASS: 400 muestras identicas al modelo de Python`.

Para simular otro testbench, en la consola Tcl:

    close_sim
    set_property top tb_dsp_top [get_filesets sim_1]
    launch_simulation

## Archivos .mem (lo que más falla)

`$readmemh` busca los `.mem` en la carpeta donde corre la simulación. Si los agregas
al proyecto de Vivado (el script ya lo hace), Vivado los copia ahí. Si ves X en vez
de números, o el testbench dice que no se cargó un `.mem`, agrégalo al proyecto
o escribe la ruta completa con `/`. Agrega cada `.mem` una sola vez.

## Pines (XDC)

Los `.xdc` son para una Digilent Basys 3. Para otra placa, copia las líneas de su
Master XDC (github.com/Digilent/digilent-xdc) y cambia solo los nombres de puerto.

## Regenerar los datos (opcional)

    pip install numpy scipy matplotlib
    cd 01_fir  && python fir_design.py      # coefs.mem, coefs.coe, x_in.mem, y_expected.mem, fir_resultado.png
    cd 02_nco  && python gen_sine_lut.py    # sine_lut.mem

Si cambias NTAPS o NSAMPLES en `fir_design.py`, cámbialos también en el testbench.

## Sin Vivado (opcional): Icarus Verilog

    cd 01_fir
    iverilog -g2005 -o sim fir_transposed.v tb_fir.v && vvp sim
