// ============================================================================
// dsp_top.v - Cadena DSP completa para la placa:
//
//    NCO 20 kHz --+
//                 +--> (a+b)/2 --> FIR pasabajos --> medidor de nivel --> 8 LEDs
//    NCO 300 kHz -+
//
//  * sel_sw = 0: los LEDs muestran el nivel de la ENTRADA del filtro (dos tonos)
//  * sel_sw = 1: los LEDs muestran el nivel de la SALIDA (solo queda 20 kHz,
//                la mitad de la amplitud -> se apagan cerca de la mitad de los LEDs)
//  * x_mix, y_filt y x_valid llevan (* mark_debug *) para verlos con un ILA.
//
//  Necesita: nco.v, fir_transposed.v, sine_lut.mem y coefs.mem en el proyecto.
// ============================================================================
`timescale 1ns / 1ps

module dsp_top #(
    parameter integer CLK_HZ  = 100_000_000,   // reloj de la placa
    parameter integer FS_HZ   = 1_000_000,     // tasa de muestreo de la cadena DSP
    parameter [31:0]  FCW_A   = 32'd85899346,  // 20 kHz  : round(20e3/1e6 * 2^32)
    parameter [31:0]  FCW_B   = 32'd1288490189,// 300 kHz : round(300e3/1e6 * 2^32)
    parameter integer METER_W = 16             // ventana del medidor: 2^16 muestras (~65 ms)
) (
    input  wire       clk,
    input  wire       rst_btn,   // boton de reset (asincrono respecto del reloj)
    input  wire       sel_sw,    // switch: 0 = ver entrada, 1 = ver salida
    output reg  [7:0] led
);
    // ---- 0) sincronizar las entradas externas con 2 flip-flops (evita metaestabilidad)
    //         El valor inicial 2'b11 es valido en FPGA AMD/Xilinx: al configurarse,
    //         el diseno parte en reset y lo suelta solo a los 2 ciclos.
    reg [1:0] rst_sync = 2'b11;
    reg [1:0] sel_sync = 2'b00;
    always @(posedge clk) begin
        rst_sync <= {rst_sync[0], rst_btn};
        sel_sync <= {sel_sync[0], sel_sw};
    end
    wire rst = rst_sync[1];
    wire sel = sel_sync[1];

    // ---- 1) habilitacion de muestra: un pulso (ce) cada CLK_HZ/FS_HZ ciclos ----
    localparam integer DIV = CLK_HZ / FS_HZ;
    reg [$clog2(DIV)-1:0] div_cnt;
    reg                   ce;
    always @(posedge clk) begin
        if (rst) begin
            div_cnt <= 0;
            ce      <= 1'b0;
        end else if (div_cnt == DIV - 1) begin
            div_cnt <= 0;
            ce      <= 1'b1;
        end else begin
            div_cnt <= div_cnt + 1'b1;
            ce      <= 1'b0;
        end
    end

    // ---- 2) dos osciladores ----
    wire signed [15:0] s_a, s_b;
    nco #(.LUT_FILE("sine_lut.mem")) nco_a (.clk(clk), .rst(rst), .ce(ce), .fcw(FCW_A), .sine(s_a));
    nco #(.LUT_FILE("sine_lut.mem")) nco_b (.clk(clk), .rst(rst), .ce(ce), .fcw(FCW_B), .sine(s_b));

    // ---- 3) mezcla (a+b)/2 ----
    // TRAMPA CLASICA: la suma de dos numeros de 16 bits necesita 17 bits.
    // Si escribieras  x_mix <= (s_a + s_b) >>> 1;  Verilog calcula la suma con
    // 16 bits (el ancho de x_mix), pierde el acarreo y la senal se da vuelta.
    wire signed [16:0] sum_ab = s_a + s_b;     // 17 bits: aqui no se pierde nada

    (* mark_debug = "true" *) reg signed [15:0] x_mix;
    (* mark_debug = "true" *) reg               x_valid;
    reg ce_d;
    always @(posedge clk) begin
        if (rst) begin
            ce_d    <= 1'b0;
            x_valid <= 1'b0;
            x_mix   <= 0;
        end else begin
            ce_d    <= ce;          // los NCO entregan su muestra 1 ciclo despues de ce
            x_valid <= ce_d;        // x_mix queda listo 1 ciclo despues de ce_d
            if (ce_d) x_mix <= sum_ab[16:1];   // dividir por 2 = descartar el bit menos significativo
        end
    end

    // ---- 4) filtro FIR ----
    (* mark_debug = "true" *) wire signed [15:0] y_filt;
    wire y_valid;
    fir_transposed #(.NTAPS(31), .COEF_FILE("coefs.mem")) fir (
        .clk(clk), .rst(rst),
        .in_valid(x_valid), .in_data(x_mix),
        .out_valid(y_valid), .out_data(y_filt)
    );

    // ---- 5) medidor de nivel: pico de |senal| en una ventana -> barra de 8 LEDs ----
    wire signed [15:0] s_meter = sel ? y_filt : x_mix;
    wire        [15:0] mag     = s_meter[15] ? -s_meter : s_meter;  // valor absoluto
    reg  [15:0]        peak, peak_hold;
    reg  [METER_W-1:0] win;
    always @(posedge clk) begin
        if (rst) begin
            peak      <= 0;
            peak_hold <= 0;
            win       <= 0;
        end else if (x_valid) begin          // una vez por muestra
            win <= win + 1'b1;
            if (win == 0) begin              // fin de ventana: congelar el pico y reiniciar
                peak_hold <= peak;
                peak      <= mag;
            end else if (mag > peak) begin
                peak <= mag;
            end
        end
    end

    integer j;
    always @(posedge clk) begin
        for (j = 0; j < 8; j = j + 1)
            led[j] <= (peak_hold > (2*j + 1) * 2048);  // umbrales en 1/16, 3/16, ... 15/16 de la escala
    end
endmodule
