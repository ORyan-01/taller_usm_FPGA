// ============================================================================
// tb_dsp_top.v - Simula la cadena completa (NCO -> mezcla -> FIR -> LEDs).
//
// Sirve para VER el filtro funcionando: en la ventana de ondas de Vivado agrega
// dut/x_mix y dut/y_filt, clic derecho > Radix > Signed Decimal y luego
// clic derecho > Waveform Style > Analog. Veras la suma de dos tonos entrar y
// una senoidal limpia de 20 kHz salir.
//
// Ademas revisa propiedades (no bit a bit): amplitud y frecuencia de la salida.
// Necesita en el proyecto: dsp_top.v, nco.v, fir_transposed.v, sine_lut.mem, coefs.mem
// ============================================================================
`timescale 1ns / 1ps

module tb_dsp_top;
    reg        clk     = 1'b0;
    reg        rst_btn = 1'b1;
    reg        sel_sw  = 1'b0;
    wire [7:0] led;

    // Ventana del medidor mas corta (2^9 = 512 muestras) para que la simulacion sea rapida
    dsp_top #(.METER_W(9)) dut (.clk(clk), .rst_btn(rst_btn), .sel_sw(sel_sw), .led(led));

    always #5 clk = ~clk;   // 100 MHz

    // ---- mediciones sobre la salida del filtro, una vez por muestra ----
    integer n = 0, cruces = 0, errores = 0;
    integer pico_x = 0, pico_y = 0;
    reg signed [15:0] y_prev = 0;

    always @(posedge clk) begin
        if (dut.x_valid) begin
            n = n + 1;
            if (n > 100 && n <= 1100) begin        // ignorar el transitorio inicial
                if ( dut.x_mix  > pico_x) pico_x =  dut.x_mix;
                if (-dut.x_mix  > pico_x) pico_x = -dut.x_mix;
                if ( dut.y_filt > pico_y) pico_y =  dut.y_filt;
                if (-dut.y_filt > pico_y) pico_y = -dut.y_filt;
                if ((y_prev < 0) != (dut.y_filt < 0)) cruces = cruces + 1;
            end
            y_prev = dut.y_filt;
        end
    end

    initial begin
        repeat (5) @(posedge clk);
        rst_btn <= 1'b0;

        // 1100 muestras a 1 MS/s = 1.1 ms de simulacion
        wait (n == 1100);
        $display("Pico de la entrada x_mix : %0d  (dos tonos de 0.5 cada uno)", pico_x);
        $display("Pico de la salida y_filt : %0d  (esperado ~16384 = 0.5)", pico_y);
        $display("Cruces por cero de y en 1 ms: %0d  (20 kHz -> 40)", cruces);
        $display("LEDs con sel=0 (entrada): %b", led);
        if (pico_y < 15500 || pico_y > 17000) errores = errores + 1;
        if (cruces < 38 || cruces > 42)       errores = errores + 1;
        if (pico_x < 25000)                   errores = errores + 1;

        sel_sw <= 1'b1;                          // ahora mirar la salida del filtro
        wait (n == 2300);
        $display("LEDs con sel=1 (salida) : %b", led);
        if (led != 8'b0000_1111) errores = errores + 1;

        if (errores == 0) $display("PASS: el filtro deja pasar 20 kHz y elimina 300 kHz");
        else              $display("FAIL: %0d chequeos no se cumplieron", errores);
        $finish;
    end
endmodule
