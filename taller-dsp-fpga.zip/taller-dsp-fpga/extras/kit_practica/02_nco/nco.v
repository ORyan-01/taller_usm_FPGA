// ============================================================================
// nco.v - Oscilador controlado numericamente (NCO, tambien llamado DDS).
//
//   fase <= fase + fcw                (acumulador de PHASE_W bits: da la vuelta solo)
//   seno <= tabla[ bits altos de fase ]   (2^LUT_AW valores de un periodo)
//
//   f_salida = fcw * f_muestreo / 2^PHASE_W
//   =>  fcw  = round(f_salida / f_muestreo * 2^PHASE_W)
//
// Con PHASE_W = 32 y f_muestreo = 1 MHz la resolucion es 1e6/2^32 = 0.23 mHz.
// El IP "DDS Compiler" de Vivado hace lo mismo, con mas opciones.
// ============================================================================
`timescale 1ns / 1ps

module nco #(
    parameter integer PHASE_W  = 32,
    parameter integer LUT_AW   = 10,             // 1024 puntos por periodo
    parameter integer OUT_W    = 16,
    parameter         LUT_FILE = "sine_lut.mem"  // generado por gen_sine_lut.py
) (
    input  wire                      clk,
    input  wire                      rst,
    input  wire                      ce,        // 1 = avanzar una muestra
    input  wire        [PHASE_W-1:0] fcw,       // palabra de sintonia (frecuencia)
    output reg  signed [OUT_W-1:0]   sine
);
    reg [PHASE_W-1:0]      phase;
    reg signed [OUT_W-1:0] lut [0:(1 << LUT_AW) - 1];
    initial $readmemh(LUT_FILE, lut);

    always @(posedge clk) begin
        if (rst) begin
            phase <= 0;
            sine  <= 0;
        end else if (ce) begin
            phase <= phase + fcw;
            // [MSB -: N] = "N bits contando hacia abajo desde MSB" (part-select indexado)
            sine  <= lut[phase[PHASE_W-1 -: LUT_AW]];
        end
    end
endmodule
