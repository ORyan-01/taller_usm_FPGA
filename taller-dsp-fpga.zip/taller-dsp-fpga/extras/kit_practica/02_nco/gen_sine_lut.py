"""
gen_sine_lut.py - Genera sine_lut.mem: un periodo de seno en 1024 puntos,
enteros Q1.15 (16 bits con signo) en hex, uno por linea.

Uso:  python gen_sine_lut.py
Tambien imprime los fcw para los tonos que usa dsp_top.v.
"""
import numpy as np

LUT_AW = 10                 # 2^10 = 1024 puntos
AMP = 2**15 - 1             # amplitud maxima sin saturar: 32767
FS = 1_000_000              # tasa de muestreo de la cadena DSP [Hz]

i = np.arange(2**LUT_AW)
lut = np.round(AMP * np.sin(2 * np.pi * i / 2**LUT_AW)).astype(np.int64)

with open("sine_lut.mem", "w") as f:
    f.write("\n".join(f"{int(v) & 0xFFFF:04X}" for v in lut) + "\n")
print(f"sine_lut.mem: {len(lut)} valores, min {lut.min()}, max {lut.max()}")

for f_hz in (20_000, 300_000):
    fcw = round(f_hz / FS * 2**32)
    print(f"fcw para {f_hz/1e3:.0f} kHz a {FS/1e6:.0f} MS/s: {fcw}  (32'd{fcw})")
