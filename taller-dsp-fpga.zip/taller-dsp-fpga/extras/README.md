# Extras

Material de práctica y versiones anteriores del transmisor. Cada carpeta es independiente.

| Carpeta | Qué hay |
|---|---|
| [`kit_practica`](kit_practica) | Ejercicios: un LED que parpadea, un FIR de 31 coeficientes en Q1.15 con modelo de oro en Python, un NCO y una cadena completa (NCO → FIR → medidor en LEDs) para la Basys 3. Trae `crear_proyecto.tcl` para armar el proyecto de Vivado con un comando |
| [`tx_rrc_q15`](tx_rrc_q15) | Versión anterior del transmisor: PRBS9 → BPSK → sobremuestreo x4 → filtro coseno alzado raíz (β = 0.35, 25 coeficientes, Q1.15) en forma transpuesta |
| [`tx_rrc_1bit`](tx_rrc_1bit) | Otra versión anterior: el filtro RRC recibe directo el bit de la PRBS9 y pide el bit siguiente con `bit_enb` |

Algunos módulos se llaman igual que en las carpetas 01 y 02 (`prbs9`, `transmisor`) pero tienen
otra interfaz, así que no mezcles carpetas en un mismo proyecto de Vivado.
