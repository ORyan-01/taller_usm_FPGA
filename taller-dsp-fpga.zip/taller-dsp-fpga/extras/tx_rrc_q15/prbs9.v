// ============================================================================
// prbs9.v - Generador de secuencia pseudoaleatoria PRBS9
//
//   Polinomio x^9 + x^5 + 1 (ITU-T O.150): un registro de desplazamiento de
//   9 etapas cuya entrada es la XOR de las etapas 5 y 9. La salida es la
//   etapa 9. La secuencia dura 2^9 - 1 = 511 bits y despues se repite.
//
//   El estado 000000000 esta prohibido: si el registro llega a 0 se queda
//   en 0 para siempre. Por eso SEED nunca puede ser 0.
// ============================================================================
`timescale 1ns / 1ps

module prbs9 #(
    parameter [8:0] SEED = 9'h1FF        // estado inicial (cualquiera menos 0)
) (
    input  wire clk,
    input  wire rst,                     // sincrono: carga SEED
    input  wire en,                      // 1 = avanzar un bit
    output wire bit_out                  // bit actual de la secuencia
);
    reg [8:0] lfsr;                      // lfsr[0] = etapa 1 ... lfsr[8] = etapa 9

    wire realimentacion = lfsr[8] ^ lfsr[4];      // etapa 9 XOR etapa 5

    always @(posedge clk) begin
        if (rst)
            lfsr <= SEED;
        else if (en)
            lfsr <= {lfsr[7:0], realimentacion};  // todo sube una etapa y entra la XOR
    end

    assign bit_out = lfsr[8];            // la salida es la etapa 9
endmodule
