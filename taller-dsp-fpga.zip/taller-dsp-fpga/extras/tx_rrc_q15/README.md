# PRBS9 + filtro de transmision (RRC)

Archivos para Vivado:
- prbs9.v, tx_filter.v, tx_top.v  -> Design Sources (tx_top es el top)
- tb_tx.v                         -> Simulation Sources (tb_tx es el top)

Simular: Run Behavioral Simulation y despues Run All (o "run all" en la Tcl Console).
Debe terminar en PASS.

Valores: PRBS9 x^9 + x^5 + 1, semilla 1FF, BPSK (0 -> +1, 1 -> -1),
RRC beta 0.35, 4 muestras por simbolo, 6 simbolos (25 coeficientes), Q1.15.

rrc_coefs.py regenera los coeficientes si cambias beta, muestras por simbolo o largo.
rrc.coe es el archivo de coeficientes para el IP FIR Compiler.

![Pulso del filtro, señal transmitida y espectro](tx_resultado.png)
