"""
rrc_coefs.py - Disena el filtro de transmision (coseno alzado raiz, RRC),
lo cuantiza a 16 bits (Q1.15) e imprime el bloque `case` listo para pegar
en tx_filter.v. Tambien escribe rrc.coe para el IP FIR Compiler de Vivado.

Uso:  python rrc_coefs.py            (necesita numpy)

Si cambias BETA, SPS o SPAN, pega el nuevo bloque en tx_filter.v y ajusta
NTAPS alli y SPS en tx_top.v.
"""
import numpy as np

BETA = 0.35      # factor de roll-off (exceso de ancho de banda)
SPS  = 4         # muestras por simbolo
SPAN = 6         # largo del filtro, en simbolos
FRAC = 15        # Q1.15

NTAPS = SPAN * SPS + 1


def rrc(beta, sps, span):
    """Coseno alzado raiz con energia 1 (misma forma que rcosdesign de MATLAB)."""
    t = np.arange(-span * sps / 2, span * sps / 2 + 1) / sps   # tiempo en simbolos
    h = np.zeros_like(t)
    for i, ti in enumerate(t):
        if abs(ti) < 1e-12:
            h[i] = 1 - beta + 4 * beta / np.pi
        elif abs(abs(4 * beta * ti) - 1) < 1e-9:
            h[i] = (beta / np.sqrt(2)) * ((1 + 2 / np.pi) * np.sin(np.pi / (4 * beta))
                                          + (1 - 2 / np.pi) * np.cos(np.pi / (4 * beta)))
        else:
            h[i] = (np.sin(np.pi * ti * (1 - beta)) + 4 * beta * ti * np.cos(np.pi * ti * (1 + beta))) \
                   / (np.pi * ti * (1 - (4 * beta * ti) ** 2))
    return h / np.sqrt(np.sum(h ** 2))


h = rrc(BETA, SPS, SPAN)

# Escala: con simbolos de +-1, en cada instante coinciden a lo mas SPAN coeficientes
# (uno de cada fase). Se escala para que la peor suma de |h| sea 0.98: la salida
# nunca pasa de +-1, o sea nunca satura.
peor = max(np.sum(np.abs(h[p::SPS])) for p in range(SPS))
h_esc = h * 0.98 / peor
h_q = np.round(h_esc * 2**FRAC).astype(int)

if __name__ == "__main__":
    print(f"RRC: beta={BETA}, {SPS} muestras/simbolo, {SPAN} simbolos -> {NTAPS} coeficientes")
    print(f"Coeficiente central: {h_q[NTAPS // 2]} ({h_q[NTAPS // 2] / 2**FRAC:.4f})")
    print("\n// ---- pegar en tx_filter.v ----")
    for k, c in enumerate(h_q):
        print(f"                {k:2d}: h = {'-' if c < 0 else ' '}16'sd{abs(c)};")
    with open("rrc.coe", "w") as f:
        f.write("radix = 10;\ncoefdata =\n" + ",\n".join(str(c) for c in h_q) + ";\n")
    print("\nrrc.coe escrito (para el IP FIR Compiler)")
