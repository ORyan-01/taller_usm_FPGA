// ============================================================================
// tb_tx.v - Testbench autoverificable del transmisor PRBS9 + filtro RRC
//
//   1) PRBS9: guarda 1022 bits y revisa que la secuencia se repita cada 511
//      bits y que tenga 256 unos y 255 ceros, como toda PRBS9 correcta.
//   2) Filtro: calcula cada salida "a mano", directo de la definicion
//      y[n] = suma de h[k] * x[n-k], y la compara con lo que entrega el
//      hardware, muestra por muestra.
//
//   En Vivado: Run Behavioral Simulation y despues Run All (o "run all" en la
//   Tcl Console). Al final imprime PASS o FAIL.
// ============================================================================
`timescale 1ns / 1ps

module tb_tx;
    parameter  integer GAP    = 0;       // ciclos sin muestra entre muestras (0 = una por ciclo)
    localparam integer NTAPS  = 25;
    localparam integer NMUEST = 4400;    // 1100 simbolos x 4 muestras

    reg                clk = 1'b0;
    reg                rst = 1'b1;
    reg                ce  = 1'b0;
    wire               bit_tx;
    wire signed [15:0] tx_out;
    wire               tx_valid;

    tx_top dut (
        .clk      (clk),
        .rst      (rst),
        .ce       (ce),
        .bit_tx   (bit_tx),
        .tx_out   (tx_out),
        .tx_valid (tx_valid)
    );

    always #5 clk = ~clk;                // reloj de 100 MHz

    // ---------------- 1) guardar los bits de la PRBS9 ----------------
    reg     bits [0:1021];
    integer nbits = 0;

    always @(posedge clk) begin
        if (dut.nuevo_simbolo && nbits < 1022) begin
            bits[nbits] = bit_tx;
            nbits = nbits + 1;
        end
    end

    // ---------------- 2) modelo de referencia del filtro ----------------
    reg signed [15:0] hist [0:NTAPS-1];  // las ultimas 25 entradas del filtro
    reg signed [47:0] suma;
    reg signed [47:0] y_ref;
    reg signed [15:0] esperado [0:8191];
    integer escritos = 0, leidos = 0, errores = 0, i;

    initial for (i = 0; i < NTAPS; i = i + 1) hist[i] = 16'sd0;

    always @(posedge clk) begin
        if (dut.x_valid) begin           // en este flanco el filtro toma una entrada
            for (i = NTAPS - 1; i > 0; i = i - 1) hist[i] = hist[i-1];
            hist[0] = dut.x;
            suma = 0;
            for (i = 0; i < NTAPS; i = i + 1)
                suma = suma + hist[i] * dut.u_fir.h(i);
            y_ref = (suma + 16384) >>> 15;                // mismo redondeo que el hardware
            if (y_ref >  32767) y_ref =  32767;           // misma saturacion
            if (y_ref < -32768) y_ref = -32768;
            esperado[escritos] = y_ref[15:0];
            escritos = escritos + 1;
        end
        if (tx_valid) begin              // el hardware entrega una salida
            if (tx_out !== esperado[leidos]) begin
                errores = errores + 1;
                if (errores <= 10)
                    $display("ERROR muestra %0d: hardware %0d, referencia %0d",
                             leidos, tx_out, esperado[leidos]);
            end
            leidos = leidos + 1;
        end
    end

    // ---------------- estimulo y resumen ----------------
    integer n, unos, repite;

    initial begin
        repeat (5) @(posedge clk);
        rst <= 1'b0;

        for (n = 0; n < NMUEST; n = n + 1) begin
            ce <= 1'b1;
            @(posedge clk);
            if (GAP > 0) begin
                ce <= 1'b0;
                repeat (GAP) @(posedge clk);
            end
        end
        ce <= 1'b0;
        repeat (10) @(posedge clk);      // vaciar el pipeline del filtro

        unos = 0;
        repite = 1;
        for (i = 0; i < 511; i = i + 1) begin
            unos = unos + bits[i];
            if (bits[i] !== bits[i + 511]) repite = 0;
        end

        $display("PRBS9: primeros 16 bits = %b%b%b%b%b%b%b%b%b%b%b%b%b%b%b%b",
                 bits[0], bits[1], bits[2], bits[3], bits[4], bits[5], bits[6], bits[7],
                 bits[8], bits[9], bits[10], bits[11], bits[12], bits[13], bits[14], bits[15]);
        $display("PRBS9: %0d unos y %0d ceros en 511 bits; se repite cada 511: %s",
                 unos, 511 - unos, repite ? "si" : "NO");
        $display("Filtro: %0d muestras comparadas con la referencia, %0d errores",
                 leidos, errores);

        if (unos == 256 && repite && errores == 0 && leidos == escritos && leidos > 0)
            $display("PASS");
        else
            $display("FAIL");
        $finish;
    end
endmodule
