// ============================================================================
// tx_top.v - Transmisor: PRBS9 -> BPSK -> sobremuestreo x4 -> filtro RRC
//
//   Cada simbolo dura SPS muestras. En la primera muestra de cada simbolo
//   entra +A o -A segun el bit de la PRBS9; en las otras SPS-1 entra 0.
//   El filtro convierte esos impulsos en pulsos suaves de ancho de banda
//   limitado: esa es la senal que se transmite.
//
//   ce = 1 durante un ciclo por cada muestra de salida. Si ce queda siempre
//   en 1, sale una muestra por ciclo de reloj.
// ============================================================================
`timescale 1ns / 1ps

module tx_top (
    input  wire               clk,
    input  wire               rst,       // sincrono, activo en alto
    input  wire               ce,        // 1 = producir una muestra
    output wire               bit_tx,    // bit de la PRBS9 que se esta enviando
    output wire signed [15:0] tx_out,    // senal filtrada (Q1.15)
    output wire               tx_valid   // 1 = hay una muestra nueva en tx_out
);
    localparam integer SPS = 4;                  // muestras por simbolo (igual que en el filtro)
    localparam signed [15:0] A = 16'sd32767;     // amplitud del simbolo: casi +1

    // ---- 1) en que muestra del simbolo vamos: 0, 1, 2, 3, 0, 1 ... ----
    reg [1:0] fase;                              // 2 bits alcanzan para contar de 0 a 3
    always @(posedge clk) begin
        if (rst)
            fase <= 2'd0;
        else if (ce)
            fase <= (fase == SPS - 1) ? 2'd0 : fase + 2'd1;
    end

    wire nuevo_simbolo = ce && (fase == 2'd0);

    // ---- 2) PRBS9: avanza un bit por simbolo ----
    prbs9 #(.SEED(9'h1FF)) u_prbs (
        .clk     (clk),
        .rst     (rst),
        .en      (nuevo_simbolo),
        .bit_out (bit_tx)
    );

    // ---- 3) BPSK + sobremuestreo con ceros ----
    reg signed [15:0] x;
    reg               x_valid;
    always @(posedge clk) begin
        if (rst) begin
            x       <= 16'sd0;
            x_valid <= 1'b0;
        end else begin
            x_valid <= ce;
            if (ce) begin
                if (fase == 2'd0)
                    x <= bit_tx ? -A : A;        // bit 0 -> +A, bit 1 -> -A
                else
                    x <= 16'sd0;                 // relleno con ceros
            end
        end
    end

    // ---- 4) filtro de transmision ----
    tx_filter u_fir (
        .clk       (clk),
        .rst       (rst),
        .in_valid  (x_valid),
        .in_data   (x),
        .out_valid (tx_valid),
        .out_data  (tx_out)
    );
endmodule
