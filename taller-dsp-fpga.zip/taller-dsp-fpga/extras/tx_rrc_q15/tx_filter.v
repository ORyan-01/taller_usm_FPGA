// ============================================================================
// tx_filter.v - Filtro de transmision: FIR coseno alzado raiz (RRC)
//
//   beta = 0.35, 4 muestras por simbolo, 6 simbolos de largo -> 25 coeficientes
//   Coeficientes en Q1.15 (entero / 32768), generados con rrc_coefs.py
//
//   Estructura transpuesta: cada muestra x llega a los 25 multiplicadores a la
//   vez y cada etapa hace  acc[k] <= acc[k+1] + x * h[k].
//   Latencia: 3 ciclos desde in_valid hasta out_valid.
// ============================================================================
`timescale 1ns / 1ps

module tx_filter (
    input  wire               clk,
    input  wire               rst,        // sincrono, activo en alto
    input  wire               in_valid,   // 1 = hay una muestra nueva en in_data
    input  wire signed [15:0] in_data,
    output reg                out_valid,
    output reg  signed [15:0] out_data
);
    localparam integer NTAPS = 25;
    localparam integer ACC_W = 16 + 16 + 5;   // producto de 32 bits + 5 bits para sumar 25

    // ---------------- coeficientes (tabla fija) ----------------
    function signed [15:0] h;
        input integer k;
        begin
            case (k)
                 0: h = -16'sd532;
                 1: h = -16'sd309;
                 2: h =  16'sd535;
                 3: h =  16'sd1365;
                 4: h =  16'sd1193;
                 5: h = -16'sd461;
                 6: h = -16'sd2824;
                 7: h = -16'sd3941;
                 8: h = -16'sd1769;
                 9: h =  16'sd4322;
                10: h =  16'sd12697;
                11: h =  16'sd19996;
                12: h =  16'sd22890;     // centro del pulso
                13: h =  16'sd19996;
                14: h =  16'sd12697;
                15: h =  16'sd4322;
                16: h = -16'sd1769;
                17: h = -16'sd3941;
                18: h = -16'sd2824;
                19: h = -16'sd461;
                20: h =  16'sd1193;
                21: h =  16'sd1365;
                22: h =  16'sd535;
                23: h = -16'sd309;
                24: h = -16'sd532;
                default: h = 16'sd0;
            endcase
        end
    endfunction

    // ---------------- etapa 0: registrar la entrada ----------------
    reg signed [15:0] x_r;
    reg               v0;
    always @(posedge clk) begin
        if (rst) begin
            x_r <= 0;
            v0  <= 1'b0;
        end else begin
            v0 <= in_valid;
            if (in_valid) x_r <= in_data;
        end
    end

    // ---------------- etapa 1: cadena de multiplicar y acumular ----------------
    reg signed [ACC_W-1:0] acc [0:NTAPS-1];
    reg                    v1;
    integer k;
    always @(posedge clk) begin
        if (rst) begin
            for (k = 0; k < NTAPS; k = k + 1) acc[k] <= 0;
            v1 <= 1'b0;
        end else begin
            v1 <= v0;
            if (v0) begin
                acc[NTAPS-1] <= x_r * h(NTAPS-1);
                for (k = 0; k < NTAPS-1; k = k + 1)
                    acc[k] <= acc[k+1] + x_r * h(k);
            end
        end
    end

    // ---------------- etapa 2: redondeo y saturacion a 16 bits ----------------
    localparam signed [ACC_W-1:0] MEDIO_LSB = 1 <<< 14;       // 0.5 en la escala de salida
    localparam signed [ACC_W-1:0] MAXIMO    =  32767;
    localparam signed [ACC_W-1:0] MINIMO    = -32768;

    wire signed [ACC_W-1:0] y_red = (acc[0] + MEDIO_LSB) >>> 15;   // vuelve a Q1.15

    always @(posedge clk) begin
        if (rst) begin
            out_valid <= 1'b0;
            out_data  <= 0;
        end else begin
            out_valid <= v1;
            if (v1) begin
                if      (y_red > MAXIMO) out_data <= 16'sh7FFF;
                else if (y_red < MINIMO) out_data <= 16'sh8000;
                else                     out_data <= y_red[15:0];
            end
        end
    end
endmodule
