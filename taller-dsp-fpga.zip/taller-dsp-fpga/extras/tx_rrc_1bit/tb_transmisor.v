`timescale 1ns / 1ps
module tb_transmisor;
    reg  CLK = 0, rst = 1, enb = 0;
    wire signed [15:0] tx;

    transmisor dut (.CLK(CLK), .rst(rst), .enb(enb), .tx(tx));

    always #5 CLK = ~CLK;                        // reloj de 100 MHz

    // ---- referencia: el filtro calculado directo de la definicion ----
    reg signed [15:0] hist [0:24];               // ultimas 25 entradas del filtro
    reg signed [47:0] suma, y_ref;
    reg signed [15:0] esperado [0:8191];
    reg     v2 = 0;
    integer i, escritos = 0, leidos = 0, errores = 0;

    initial for (i = 0; i < 25; i = i + 1) hist[i] = 0;

    always @(posedge CLK) begin
        if (dut.u_filtro.v0) begin               // el filtro toma una entrada
            for (i = 24; i > 0; i = i - 1) hist[i] = hist[i-1];
            hist[0] = dut.u_filtro.x;
            suma = 0;
            for (i = 0; i < 25; i = i + 1) suma = suma + hist[i] * dut.u_filtro.h(i);
            y_ref = (suma + 16384) >>> 15;
            esperado[escritos] = y_ref[15:0];
            escritos = escritos + 1;
        end
        v2 <= dut.u_filtro.v1;                   // tx se actualiza cuando v1 = 1
        if (v2) begin                            // un ciclo despues, se compara
            if (tx !== esperado[leidos]) errores = errores + 1;
            leidos = leidos + 1;
        end
    end

    initial begin
        repeat (3) @(posedge CLK);
        rst <= 0;
        enb <= 1;                                // una muestra por ciclo
        repeat (4400) @(posedge CLK);            // 1100 simbolos x 4 muestras
        enb <= 0;
        repeat (10) @(posedge CLK);
        $display("%0d muestras comparadas con la referencia, %0d errores", leidos, errores);
        if (errores == 0 && leidos == escritos) $display("PASS"); else $display("FAIL");
        $finish;
    end
endmodule
