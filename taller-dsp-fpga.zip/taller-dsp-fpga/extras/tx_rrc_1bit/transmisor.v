// transmisor.v - PRBS9 conectada al filtro de transmision
`timescale 1ns / 1ps

module transmisor (
    input  wire               CLK,
    input  wire               rst,
    input  wire               enb,       // 1 = una muestra de salida
    output wire signed [15:0] tx         // senal a transmitir
);
    wire bit_prbs;                       // bit que sale de la PRBS9
    wire pedir_bit;                      // el filtro pide el siguiente bit

    prbs9 #(.seed(32'h0A0A_0505)) u_prbs (
        .CLK(CLK), .rst(rst), .enb(pedir_bit), .salida(bit_prbs)
    );

    filtro_tx u_filtro (
        .CLK(CLK), .rst(rst), .enb(enb), .din(bit_prbs), .bit_enb(pedir_bit), .dout(tx)
    );
endmodule
