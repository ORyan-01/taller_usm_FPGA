# PRBS9 + filtro RRC con entrada de 1 bit

El filtro de transmisión recibe directo el bit de la PRBS9 y entrega 4 muestras por símbolo en
16 bits con signo (Q1.15). Cuando necesita el bit siguiente, pone `bit_enb` en 1; esa señal va
conectada al `enb` de la PRBS9.

| Archivo | Qué es |
|---|---|
| `prbs9.v` | PRBS9 x⁹ + x⁵ + 1, `seed = 32'h0A0A_0505` |
| `filtro_tx.v` | Filtro coseno alzado raíz: β = 0.35, 4 muestras por símbolo, 25 coeficientes |
| `transmisor.v` | Top: une la PRBS9 y el filtro |
| `tb_transmisor.v` | Testbench que se revisa solo: imprime `PASS` o `FAIL` |

Mapeo: bit 0 → +1, bit 1 → −1, seguido de 3 ceros, y todo eso pasa por el filtro.

## Con Icarus Verilog

    iverilog -g2005 -o sim prbs9.v filtro_tx.v transmisor.v tb_transmisor.v && vvp sim
