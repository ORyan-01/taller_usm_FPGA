// ============================================================================
// filtro_tx.v - Filtro de transmision: coseno alzado raiz (RRC)
//   beta = 0.35, 4 muestras por simbolo, 6 simbolos de largo = 25 coeficientes
//
//   Recibe un bit por simbolo (la salida de la PRBS9) y entrega 4 muestras
//   por simbolo: bit 0 -> +1, bit 1 -> -1, seguido de 3 ceros, filtrado.
//   bit_enb vale 1 cuando el filtro toma el bit: conectalo al enb de la PRBS9.
//   Salida en 16 bits con signo (Q1.15: -32768 = -1, 32767 = casi +1).
// ============================================================================
`timescale 1ns / 1ps

module filtro_tx (
    input  wire               CLK,
    input  wire               rst,       // 1 = reinicia el filtro
    input  wire               enb,       // 1 = calcula una muestra de salida
    input  wire               din,       // bit de entrada (salida de la PRBS9)
    output wire               bit_enb,   // 1 = toma din: avanza la PRBS9
    output reg  signed [15:0] dout       // senal de transmision
);
    localparam integer NTAPS = 25;
    localparam integer ACC_W = 37;                 // 16 x 16 bits + 5 bits para sumar 25
    localparam signed [15:0] A = 16'sd32767;       // amplitud del simbolo: casi +1

    // ---- coeficientes RRC en Q1.15 ----
    function signed [15:0] h;
        input integer k;
        begin
            case (k)
                 0: h = -16'sd532;    1: h = -16'sd309;    2: h =  16'sd535;
                 3: h =  16'sd1365;   4: h =  16'sd1193;   5: h = -16'sd461;
                 6: h = -16'sd2824;   7: h = -16'sd3941;   8: h = -16'sd1769;
                 9: h =  16'sd4322;  10: h =  16'sd12697; 11: h =  16'sd19996;
                12: h =  16'sd22890; 13: h =  16'sd19996; 14: h =  16'sd12697;
                15: h =  16'sd4322;  16: h = -16'sd1769;  17: h = -16'sd3941;
                18: h = -16'sd2824;  19: h = -16'sd461;   20: h =  16'sd1193;
                21: h =  16'sd1365;  22: h =  16'sd535;   23: h = -16'sd309;
                24: h = -16'sd532;
                default: h = 16'sd0;
            endcase
        end
    endfunction

    // ---- 1) muestra dentro del simbolo: 0, 1, 2, 3, 0 ... ----
    reg [1:0] fase;
    always @(posedge CLK) begin
        if (rst)      fase <= 2'd0;
        else if (enb) fase <= fase + 2'd1;         // con 2 bits, despues de 3 vuelve a 0 solo
    end

    assign bit_enb = enb && (fase == 2'd0);        // primera muestra de cada simbolo

    // ---- 2) BPSK + relleno con ceros ----
    reg signed [15:0] x;
    reg               v0;
    always @(posedge CLK) begin
        if (rst) begin
            x  <= 16'sd0;
            v0 <= 1'b0;
        end else begin
            v0 <= enb;
            if (enb) x <= (fase == 2'd0) ? (din ? -A : A) : 16'sd0;
        end
    end

    // ---- 3) FIR transpuesto: acc[k] <= acc[k+1] + x * h[k] ----
    reg signed [ACC_W-1:0] acc [0:NTAPS-1];
    reg                    v1;
    integer k;
    always @(posedge CLK) begin
        if (rst) begin
            for (k = 0; k < NTAPS; k = k + 1) acc[k] <= 0;
            v1 <= 1'b0;
        end else begin
            v1 <= v0;
            if (v0) begin
                acc[NTAPS-1] <= x * h(NTAPS-1);
                for (k = 0; k < NTAPS-1; k = k + 1)
                    acc[k] <= acc[k+1] + x * h(k);
            end
        end
    end

    // ---- 4) redondeo y saturacion a 16 bits ----
    wire signed [ACC_W-1:0] y = (acc[0] + 16384) >>> 15;
    always @(posedge CLK) begin
        if (rst)
            dout <= 16'sd0;
        else if (v1) begin
            if      (y >  32767) dout <= 16'sh7FFF;
            else if (y < -32768) dout <= 16'sh8000;
            else                 dout <= y[15:0];
        end
    end
endmodule
