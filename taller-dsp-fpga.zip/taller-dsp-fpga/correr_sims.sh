#!/usr/bin/env bash
# Corre todos los testbenches del repositorio con Icarus Verilog (iverilog + vvp).
# Uso, desde la carpeta del repositorio:   ./correr_sims.sh

cd "$(dirname "$0")" || exit 1
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
fallas=0

# prueba "nombre" archivo.v archivo.v ...
# Compila en una carpeta temporal y copia ahi los .mem que leen los $readmemh.
prueba() {
  local nombre=$1; shift
  local archivos=() f salida
  rm -rf "${tmp:?}"/*
  for f in "$@"; do
    archivos+=("$PWD/$f")
    cp "$(dirname "$f")"/*.mem "$tmp"/ 2>/dev/null
  done
  if ! (cd "$tmp" && iverilog -g2005 -o sim "${archivos[@]}"); then
    echo "FAIL  $nombre (no compila)"; fallas=$((fallas + 1)); return
  fi
  salida=$(cd "$tmp" && vvp -n sim)
  if   grep -q "^PASS" <<< "$salida"; then echo "PASS  $nombre"
  elif grep -q "FAIL" <<< "$salida";  then echo "FAIL  $nombre"; fallas=$((fallas + 1))
  else echo "OK    $nombre (no imprime PASS/FAIL: se revisa mirando la onda)"
  fi
}

d=01_prbs9_filtro_fir
prueba "01 transmisor: PRBS9 + filtro_fir" $d/prbs9.v $d/filtro_fir.v $d/transmisor.v $d/tb_transmisor.v
prueba "01 testbench del curso"            $d/filtro_fir.v $d/tb_filtro_fir.v

d=02_transmisor_polifasico
prueba "02 transmisor polifasico" $d/prbs9.v $d/set_Coeff.v $d/filtro_fir8.v $d/top_tx.v $d/tb_top_tx.v

d=extras/kit_practica
prueba "extras: blinky"         $d/00_blinky/blinky.v $d/00_blinky/tb_blinky.v
prueba "extras: FIR 31 coef"    $d/01_fir/fir_transposed.v $d/01_fir/tb_fir.v
prueba "extras: cadena DSP"     $d/02_nco/nco.v $d/01_fir/fir_transposed.v $d/03_top/dsp_top.v $d/03_top/tb_dsp_top.v

d=extras/tx_rrc_q15
prueba "extras: TX RRC Q1.15"   $d/prbs9.v $d/tx_filter.v $d/tx_top.v $d/tb_tx.v

d=extras/tx_rrc_1bit
prueba "extras: TX RRC 1 bit"   $d/prbs9.v $d/filtro_tx.v $d/transmisor.v $d/tb_transmisor.v

echo
if [ $fallas -eq 0 ]; then echo "Todo bien"; else echo "$fallas prueba(s) con FAIL"; fi
exit $fallas
