# Taller de DSP con FPGA

Diseños en Verilog del taller de DSP con FPGA (USM, octubre 2026): un generador PRBS9, un filtro
FIR de transmisión en punto fijo y un transmisor polifásico con 8 muestras por símbolo.

Cada carpeta es un proyecto aparte y trae un testbench que se revisa solo e imprime `PASS` o `FAIL`.

## Contenido

| Carpeta | Qué hay |
|---|---|
| [`01_prbs9_filtro_fir`](01_prbs9_filtro_fir) | PRBS9 → BPSK → filtro FIR de 4 coeficientes `[-1, 1/2, -1/4, 1/8]` en S(8,7) |
| [`02_transmisor_polifasico`](02_transmisor_polifasico) | Top con solo `clk`: PRBS9 → 8 filtros de 8 coeficientes (64 en total) → mux 8 a 1 |
| [`extras`](extras) | Kit de práctica (blinky, FIR de 31 coeficientes, NCO) y dos versiones anteriores del transmisor con filtro RRC |

## Transmisor polifásico

```mermaid
flowchart LR
    clk(["clk"]) --> por["Reset de encendido"]
    por --> cnt["Contador de fase 0…7"]
    cnt -- "1 de cada 8 ciclos" --> prbs["PRBS9"]
    prbs --> bpsk["BPSK ±0.5"]
    bpsk --> f0["Filtro fase 0"]
    bpsk --> fx["Filtros fase 1…6"]
    bpsk --> f7["Filtro fase 7"]
    f0 --> mux["Mux 8:1"]
    fx --> mux
    f7 --> mux
    cnt -- "selección" --> mux
    mux --> out(["o_tx · S(12,10)"])
```

El pulso de transmisión tiene 64 coeficientes h[0…63] y cada símbolo dura 8 muestras.
El filtro de la fase p usa h[p], h[p+8], …, h[p+56], y en la fase p el mux saca ese filtro:

    y[8n + p] = h[p]·a[n] + h[p+8]·a[n-1] + ... + h[p+56]·a[n-7]

Da lo mismo que meter los símbolos con 7 ceros entre medio a un filtro de 64 coeficientes,
pero sin hacer las multiplicaciones por cero.

## Módulos

| Módulo | Carpeta | Qué hace |
|---|---|---|
| `prbs9` | 01, 02 | LFSR x⁹ + x⁵ + 1, secuencia de 511 bits. Parámetro `seed` (usa sus 9 bits de abajo); `rst = 1` carga la semilla y `enb = 1` avanza un bit |
| `filtro_fir` | 01 | FIR en forma directa de 4 coeficientes. Entrada, coeficientes y salida en S(8,7); trunca y satura |
| `transmisor` | 01 | PRBS9 + BPSK + `filtro_fir` |
| `set_Coeff` | 02 | Los 64 coeficientes del pulso en S(12,10), en un bus plano de 768 bits |
| `filtro_fir8` | 02 | FIR de 8 coeficientes que entran por puerto. S(8,7) × S(12,10), salida S(12,10) |
| `top_tx` | 02 | Reset de encendido, contador de fase, PRBS9, 8 `filtro_fir8` y mux 8 a 1 |

## Cómo simular

**Icarus Verilog:** desde esta carpeta, corre todos los testbenches del repositorio:

    ./correr_sims.sh

**Vivado:** cada carpeta tiene su README con los pasos. En corto: los `.v` de diseño van como
Design Sources, el `tb_*.v` como Simulation Source, luego Set as Top, Run Behavioral Simulation
y Run All.

## Verificación

- **PRBS9:** 256 unos y 255 ceros en 511 bits, y la secuencia se repite cada 511.
- **`filtro_fir`:** 1124 muestras comparadas con un modelo de referencia, 0 errores. El testbench
  del curso (`tb_filtro_fir.v`) corre sin cambios.
- **Transmisor polifásico:** 4800 muestras comparadas con el filtro de 64 coeficientes calculado
  directo, 0 errores. En el instante de cada símbolo la salida vale exactamente ±0.5: el pulso vale
  1 en su centro y 0 cada 8 muestras, así que los símbolos vecinos no se mezclan.
- Probado en simulación con Icarus Verilog 12.

## Notas

- `01_prbs9_filtro_fir/tb_filtro_fir.v` es el testbench del curso, sin cambios (el autor está en
  el encabezado).
- Los 64 coeficientes de `set_Coeff.v` vienen del curso. Hubo dos cambios: el puerto pasó de
  arreglo (`coeff_m [0:63]`, que es SystemVerilog) a un bus plano para que sea Verilog, y el
  formato quedó como S(12,10), porque `12'h400` = 1.0. Los valores hex son los mismos.
