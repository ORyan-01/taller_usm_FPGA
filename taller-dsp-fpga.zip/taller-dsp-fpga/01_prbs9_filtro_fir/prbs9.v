// PRBS9: polinomio x^9 + x^5 + 1, secuencia de 511 bits
`timescale 1ns/1ps

module prbs9 #(
    parameter [31:0] seed = 32'h0A0A_0505  // semilla: se usan sus 9 bits de abajo (9'h105)
) (
    input  wire CLK,
    input  wire rst,                   // 1 = carga seed, 0 = funciona
    input  wire enb,                   // 1 = avanza un bit, 0 = se queda quieto
    output wire salida                 // 1 bit
);
    reg [8:0] lfsr;

    always @(posedge CLK) begin
        if (rst)
            lfsr <= seed[8:0];                       // rst = 1: carga los 9 bits de abajo de seed
        else if (enb)
            lfsr <= {lfsr[7:0], lfsr[8] ^ lfsr[4]};  // desplaza y entra la XOR de las etapas 9 y 5
    end

    assign salida = lfsr[8];
endmodule
