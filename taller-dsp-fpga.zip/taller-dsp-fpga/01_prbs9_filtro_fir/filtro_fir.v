//! @title FIR Filter - Filtro de transmision
//! @file filtro_fir.v
//! - Filtro FIR de 4 coeficientes en forma directa: [-1, 1/2, -1/4, 1/8]
//! - y[n] = -1*x[n] + 1/2*x[n-1] - 1/4*x[n-2] + 1/8*x[n-3]
//! - Entrada, coeficientes y salida en punto fijo S(8,7): 8 bits, 7 fraccionarios
//! - **i_srst** reset sincrono: pone en 0 las muestras guardadas.
//! - **i_en** = 1 avanza el filtro; = 0 lo congela sin cambiar su estado.

`timescale 1ns/1ps

module filtro_fir
  #(
    parameter NB_INPUT   = 8, //! NB of input
    parameter NBF_INPUT  = 7, //! NBF of input
    parameter NB_OUTPUT  = 8, //! NB of output
    parameter NBF_OUTPUT = 7, //! NBF of output
    parameter NB_COEFF   = 8, //! NB of Coefficients
    parameter NBF_COEFF  = 7  //! NBF of Coefficients
  )
  (
    output signed [NB_OUTPUT-1:0] o_os_data, //! Muestra de salida
    input  signed [NB_INPUT -1:0] i_is_data, //! Muestra de entrada
    input                         i_srst,    //! Reset sincrono
    input                         i_en,      //! Enable
    input                         clk        //! Reloj
  );

  // ---- anchos internos ----
  localparam NB_PROD  = NB_INPUT  + NB_COEFF;            //! 16: producto completo
  localparam NBF_PROD = NBF_INPUT + NBF_COEFF;           //! 14 bits fraccionarios
  localparam NB_ADD   = NB_PROD + 2;                     //! 18: +2 bits para sumar 4 productos
  localparam NB_TRUNC = NBF_PROD - NBF_OUTPUT;           //! 7 bits fraccionarios que se botan
  localparam NB_CHECK = NB_ADD - NB_TRUNC - NB_OUTPUT + 1; //! 4 bits de arriba que deben ser iguales

  // ---- coeficientes S(8,7) (escritos para NB_COEFF = 8, NBF_COEFF = 7) ----
  wire signed [NB_COEFF-1:0] coeff [0:3];
  assign coeff[0] = 8'b1000_0000;   //! -1
  assign coeff[1] = 8'b0100_0000;   //!  1/2
  assign coeff[2] = 8'b1110_0000;   //! -1/4
  assign coeff[3] = 8'b0001_0000;   //!  1/8

  // ---- registro de desplazamiento: x[n-1], x[n-2], x[n-3] ----
  reg signed [NB_INPUT-1:0] x_reg [1:3];
  always @(posedge clk) begin
    if (i_srst) begin
      x_reg[1] <= {NB_INPUT{1'b0}};
      x_reg[2] <= {NB_INPUT{1'b0}};
      x_reg[3] <= {NB_INPUT{1'b0}};
    end
    else if (i_en) begin
      x_reg[1] <= i_is_data;
      x_reg[2] <= x_reg[1];
      x_reg[3] <= x_reg[2];
    end
  end

  // ---- productos: S(8,7) x S(8,7) = S(16,14) ----
  wire signed [NB_PROD-1:0] prod [0:3];
  assign prod[0] = coeff[0] * i_is_data;
  assign prod[1] = coeff[1] * x_reg[1];
  assign prod[2] = coeff[2] * x_reg[2];
  assign prod[3] = coeff[3] * x_reg[3];

  // ---- suma: S(18,14) ----
  wire signed [NB_ADD-1:0] sum = prod[0] + prod[1] + prod[2] + prod[3];

  // ---- salida S(8,7): trunca 7 bits fraccionarios y satura ----
  wire [NB_CHECK-1:0] top_bits     = sum[NB_ADD-1 -: NB_CHECK];
  wire                sin_overflow = (&top_bits) | (~|top_bits);   // todos 1 o todos 0

  assign o_os_data = sin_overflow   ? sum[NB_TRUNC + NB_OUTPUT - 1 : NB_TRUNC] :
                     sum[NB_ADD-1]  ? {1'b1, {(NB_OUTPUT-1){1'b0}}} :    // satura a -1
                                      {1'b0, {(NB_OUTPUT-1){1'b1}}};     // satura a +0,99

endmodule
