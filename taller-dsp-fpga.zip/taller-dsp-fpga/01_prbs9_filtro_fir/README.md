# 01 · PRBS9 + filtro FIR de transmisión

PRBS9 → BPSK (bit 0 = +0.5, bit 1 = −0.5) → `filtro_fir` `[-1, 1/2, -1/4, 1/8]` → `o_os_data` en S(8,7)

| Archivo | Qué es |
|---|---|
| `prbs9.v` | PRBS9 x⁹ + x⁵ + 1, parámetro `seed = 32'h0A0A_0505` (usa los 9 bits de abajo) |
| `filtro_fir.v` | FIR de 4 coeficientes en forma directa, con la misma interfaz que el testbench del curso |
| `transmisor.v` | Top: une la PRBS9 y el filtro |
| `tb_transmisor.v` | Testbench que se revisa solo: imprime `PASS` o `FAIL` |
| `tb_filtro_fir.v` | Testbench del curso, sin cambios |

## Punto fijo

- Cada producto es S(8,7) × S(8,7) = S(16,14).
- Sumar 4 productos necesita 2 bits más: S(18,14).
- La salida bota los 7 bits fraccionarios de abajo (trunca) y satura si el número no cabe en S(8,7).
- Los símbolos valen ±0.5 porque los coeficientes suman 1.875 en valor absoluto: así la salida
  llega como máximo a ±0.9375 y nunca satura.

## En Vivado

1. Add Sources → design sources: `prbs9.v`, `filtro_fir.v`, `transmisor.v`.
2. Add Sources → simulation sources: `tb_transmisor.v` (y `tb_filtro_fir.v` para probar el filtro solo).
3. Simulation Sources → clic derecho en `tb_transmisor` → Set as Top.
4. Run Behavioral Simulation → Run All. En la Tcl Console debe salir `PASS`.
5. Onda: clic derecho en `tb_os_data` → Radix → Signed Decimal, y Waveform Style → Analog.

## Con Icarus Verilog

    iverilog -g2005 -o sim prbs9.v filtro_fir.v transmisor.v tb_transmisor.v && vvp sim

Resultado: PRBS9 con 256 unos y 255 ceros y período 511; 1124 muestras del filtro comparadas con
un modelo de referencia, 0 errores.
