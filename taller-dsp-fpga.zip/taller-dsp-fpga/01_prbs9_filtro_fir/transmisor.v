//! @title Transmisor: PRBS9 + filtro FIR
//! @file transmisor.v
//! - La PRBS9 entrega un bit nuevo en cada ciclo con i_en = 1.
//! - Mapeo BPSK en S(8,7): bit 0 -> +0.5 (8'b0100_0000), bit 1 -> -0.5 (8'b1100_0000).
//! - filtro_fir filtra los simbolos: o_os_data es la senal transmitida.
//! - **i_srst** carga la semilla en la PRBS9 y limpia el filtro.

`timescale 1ns/1ps

module transmisor
  #(
    parameter [31:0] SEED = 32'h0A0A_0505   //! semilla de la PRBS9 (usa los 9 bits de abajo)
  )
  (
    output signed [7:0] o_os_data,   //! senal transmitida S(8,7)
    output              o_bit,       //! bit de la PRBS9 (para mirar)
    input               i_srst,      //! reset sincrono
    input               i_en,        //! enable
    input               clk          //! reloj
  );

  localparam signed [7:0] MAS_MEDIO   = 8'b0100_0000;  //! +0.5 en S(8,7)
  localparam signed [7:0] MENOS_MEDIO = 8'b1100_0000;  //! -0.5 en S(8,7)

  wire signed [7:0] simbolo;

  //! Generador PRBS9
  prbs9 #(.seed(SEED)) u_prbs9 (
    .CLK    (clk),
    .rst    (i_srst),
    .enb    (i_en),
    .salida (o_bit)
  );

  //! BPSK: bit 0 -> +0.5, bit 1 -> -0.5
  assign simbolo = o_bit ? MENOS_MEDIO : MAS_MEDIO;

  //! Filtro de transmision
  filtro_fir
    #(
      .NB_INPUT   (8),
      .NBF_INPUT  (7),
      .NB_OUTPUT  (8),
      .NBF_OUTPUT (7),
      .NB_COEFF   (8),
      .NBF_COEFF  (7)
    )
    u_filtro_fir (
      .o_os_data (o_os_data),
      .i_is_data (simbolo),
      .i_srst    (i_srst),
      .i_en      (i_en),
      .clk       (clk)
    );

endmodule
