//! @title Transmisor - Testbench
//! @file tb_transmisor.v
//! - Revisa que la PRBS9 se repita cada 511 bits con 256 unos y 255 ceros.
//! - Calcula cada salida del filtro con un modelo de referencia y la compara.
//! - Al final imprime PASS o FAIL.

`timescale 1ns/1ps

module tb_transmisor ();

  reg        tb_clk;
  reg        tb_en;
  reg        tb_srst;
  wire [7:0] tb_os_data;
  wire       tb_bit;

  reg        aux_tb_en;
  reg        aux_tb_srst;

  //! Instancia del transmisor
  transmisor
    #(
      .SEED (32'h0A0A_0505)
    )
    u_transmisor (
      .o_os_data (tb_os_data),
      .o_bit     (tb_bit),
      .i_srst    (tb_srst),
      .i_en      (tb_en),
      .clk       (tb_clk)
    );

  // Clock
  always #20 tb_clk = ~tb_clk;

  always @(posedge tb_clk) begin
    tb_en   <= aux_tb_en;
    tb_srst <= aux_tb_srst;
  end

  // Verificacion
  integer s1, s2, s3;              // simbolos anteriores x[n-1], x[n-2], x[n-3]
  integer s0, acc, esperado;
  integer n = 0, errores = 0, unos = 0, repite = 1, k;
  reg     bits [0:1021];

  always @(posedge tb_clk) begin
    if (tb_srst) begin
      s1 = 0; s2 = 0; s3 = 0;
    end
    else if (tb_en) begin
      s0       = tb_bit ? -64 : 64;                         // +-0.5 en S(8,7)
      acc      = -128*s0 + 64*s1 - 32*s2 + 16*s3;           // coeficientes [-1, 1/2, -1/4, 1/8]
      esperado = acc >>> 7;                                 // trunca a S(8,7)
      if (esperado >  127) esperado =  127;                 // satura
      if (esperado < -128) esperado = -128;
      if ($signed(tb_os_data) !== esperado) errores = errores + 1;
      if (n < 10)
        $display("n=%0d  bit=%b  salida=%0d  (%f)", n, tb_bit,
                 $signed(tb_os_data), $itor($signed(tb_os_data)) / 128.0);
      if (n < 1022) bits[n] = tb_bit;
      n  = n + 1;
      s3 = s2; s2 = s1; s1 = s0;
    end
  end

  // Stimulus
  initial begin
    $display("");
    $display("Simulation Started");
    tb_clk      = 1'b1;
    #5;
    aux_tb_en   = 1'b1;
    aux_tb_srst = 1'b1;
    #40;
    aux_tb_en   = 1'b1;
    aux_tb_srst = 1'b0;
    #45000;                                              // ~1100 ciclos de 40 ns

    for (k = 0; k < 511; k = k + 1) begin
      unos = unos + bits[k];
      if (bits[k] !== bits[k + 511]) repite = 0;
    end
    $display("PRBS9: %0d unos y %0d ceros en 511 bits; se repite cada 511: %s",
             unos, 511 - unos, repite ? "si" : "NO");
    $display("Filtro: %0d muestras revisadas, %0d errores", n, errores);
    if (unos == 256 && repite && errores == 0 && n >= 1022)
      $display("PASS");
    else
      $display("FAIL");
    $display("Simulation Finished");
    $display("");
    $finish;
  end

endmodule
