//! @title FIR de 8 coeficientes - Filtro de transmision (una fase)
//! @file filtro_fir8.v
//! - Igual que filtro_fir, pero con 8 coeficientes que llegan por el puerto i_coeff.
//! - y[n] = c0*x[n] + c1*x[n-1] + ... + c7*x[n-7]
//! - Entrada S(8,7), coeficientes S(12,10), salida S(12,10)
//! - **i_srst** reset sincrono: pone en 0 las muestras guardadas.
//! - **i_en** = 1 avanza el filtro; = 0 lo congela sin cambiar su estado.

`timescale 1ns/1ps

module filtro_fir8
  #(
    parameter NB_INPUT   = 8,  //! NB of input
    parameter NBF_INPUT  = 7,  //! NBF of input
    parameter NB_OUTPUT  = 12, //! NB of output
    parameter NBF_OUTPUT = 10, //! NBF of output
    parameter NB_COEFF   = 12, //! NB of Coefficients
    parameter NBF_COEFF  = 10  //! NBF of Coefficients
  )
  (
    output signed [NB_OUTPUT-1:0]  o_os_data, //! Muestra de salida
    input  signed [NB_INPUT -1:0]  i_is_data, //! Muestra de entrada
    input         [8*NB_COEFF-1:0] i_coeff,   //! 8 coeficientes: c0 en los 12 bits de abajo
    input                          i_srst,    //! Reset sincrono
    input                          i_en,      //! Enable
    input                          clk        //! Reloj
  );

  // ---- anchos internos ----
  localparam NTAPS    = 8;
  localparam NB_PROD  = NB_INPUT  + NB_COEFF;               //! 20: producto completo
  localparam NBF_PROD = NBF_INPUT + NBF_COEFF;              //! 17 bits fraccionarios
  localparam NB_ADD   = NB_PROD + 3;                        //! 23: +3 bits para sumar 8 productos
  localparam NB_TRUNC = NBF_PROD - NBF_OUTPUT;              //! 7 bits fraccionarios que se botan
  localparam NB_CHECK = NB_ADD - NB_TRUNC - NB_OUTPUT + 1;  //! 5 bits de arriba que deben ser iguales

  // ---- registro de desplazamiento: x_reg[k] = x[n-k] ----
  reg signed [NB_INPUT-1:0] x_reg [1:NTAPS-1];
  integer i;
  always @(posedge clk) begin
    if (i_srst) begin
      for (i = 1; i < NTAPS; i = i + 1)
        x_reg[i] <= {NB_INPUT{1'b0}};
    end
    else if (i_en) begin
      x_reg[1] <= i_is_data;
      for (i = 2; i < NTAPS; i = i + 1)
        x_reg[i] <= x_reg[i-1];
    end
  end

  // ---- coeficientes y productos: S(8,7) x S(12,10) = S(20,17) ----
  wire signed [NB_COEFF-1:0] coeff [0:NTAPS-1];
  wire signed [NB_PROD -1:0] prod  [0:NTAPS-1];
  genvar k;
  generate
    for (k = 0; k < NTAPS; k = k + 1) begin : g_tap
      assign coeff[k] = i_coeff[k*NB_COEFF +: NB_COEFF];   // separa el bus en 8 numeros
      if (k == 0) begin : g_actual
        assign prod[k] = coeff[k] * i_is_data;             // muestra actual x[n]
      end
      else begin : g_pasada
        assign prod[k] = coeff[k] * x_reg[k];              // muestras guardadas x[n-k]
      end
    end
  endgenerate

  // ---- suma en arbol (de a pares, 3 niveles): S(23,17) ----
  wire signed [NB_ADD-1:0] sum = ((prod[0] + prod[1]) + (prod[2] + prod[3]))
                               + ((prod[4] + prod[5]) + (prod[6] + prod[7]));

  // ---- salida S(12,10): trunca 7 bits fraccionarios y satura ----
  wire [NB_CHECK-1:0] top_bits     = sum[NB_ADD-1 -: NB_CHECK];
  wire                sin_overflow = (&top_bits) | (~|top_bits);   // todos 1 o todos 0

  assign o_os_data = sin_overflow  ? sum[NB_TRUNC + NB_OUTPUT - 1 : NB_TRUNC] :
                     sum[NB_ADD-1] ? {1'b1, {(NB_OUTPUT-1){1'b0}}} :    // satura a -2
                                     {1'b0, {(NB_OUTPUT-1){1'b1}}};     // satura a +1.999

endmodule
