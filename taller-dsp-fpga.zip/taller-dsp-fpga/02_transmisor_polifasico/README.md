# 02 · Transmisor polifásico (PRBS9 + 8 filtros + mux)

Entrada: solo `clk`. Salida: `o_tx`, la señal transmitida en S(12,10), con 8 muestras por símbolo.

PRBS9 → BPSK (0 → +0.5, 1 → −0.5) → 8 filtros de 8 coeficientes (uno por fase) → mux 8 a 1 → `o_tx`

| Archivo | Qué es |
|---|---|
| `prbs9.v` | PRBS9 x⁹ + x⁵ + 1, `seed = 32'h0A0A_0505` (el mismo de la carpeta 01) |
| `set_Coeff.v` | Los 64 coeficientes del pulso, en un bus plano de 768 bits |
| `filtro_fir8.v` | Filtro de transmisión de 8 coeficientes: como `filtro_fir`, pero los coeficientes entran por puerto |
| `top_tx.v` | Top: reset de encendido, contador de fase, PRBS9, 8 filtros y mux |
| `tb_top_tx.v` | Testbench que se revisa solo: imprime `PASS` o `FAIL` |

## Cómo funciona

- **Reset de encendido:** como el top no tiene pin de reset, un contador que parte en 0 mantiene
  el reset durante los primeros 15 ciclos.
- **Contador de fase:** va de 0 a 7. Cuando vale 7, la PRBS9 avanza un bit y los 8 filtros guardan
  el símbolo nuevo.
- **Filtros:** el de la fase p usa h[p], h[p+8], h[p+16], …, h[p+56].
- **Mux:** en la fase p saca el filtro p. La salida pasa por un registro, así que aparece 1 ciclo
  después.

La salida queda:

    y[8n + p] = h[p]·a[n] + h[p+8]·a[n-1] + ... + h[p+56]·a[n-7]

Es lo mismo que meter los símbolos con 7 ceros entre medio a un filtro de 64 coeficientes, pero
sin hacer las multiplicaciones por cero.

## Punto fijo

- Cada producto es S(8,7) × S(12,10) = S(20,17).
- Sumar 8 productos necesita 3 bits más: S(23,17). La suma se hace de a pares, en árbol.
- La salida bota 7 bits fraccionarios (trunca) y queda en S(12,10), que va de −2 a +2.
- Con símbolos de ±0.5 la salida llega como máximo a ±1.067: nunca satura.

## Formato de los coeficientes

El `set_Coeff` original decía S(12,8) en el encabezado, pero los valores son S(12,10): `12'h400`
vale 1.0 recién con 10 bits fraccionarios (con 8 valdría 4.0). Los hex quedaron iguales.

El original además sacaba los coeficientes por un puerto que es un arreglo (`coeff_m [0:63]`).
Eso es SystemVerilog y no compila como Verilog, así que ahora salen en un bus plano:
`o_coeff[k*12 +: 12]` es el coeficiente k.

## En Vivado

1. Add Sources → design sources: `prbs9.v`, `set_Coeff.v`, `filtro_fir8.v`, `top_tx.v`.
2. Add Sources → simulation sources: `tb_top_tx.v`.
3. Clic derecho en `top_tx` (Design Sources) y en `tb_top_tx` (Simulation Sources) → Set as Top.
4. Run Behavioral Simulation → Run All. En la Tcl Console debe salir `PASS` (a los 50 µs).
5. Onda: clic derecho en `tb_tx` → Radix → Signed Decimal, y Waveform Style → Analog.

## Con Icarus Verilog

    iverilog -g2005 -o sim prbs9.v set_Coeff.v filtro_fir8.v top_tx.v tb_top_tx.v && vvp sim

Resultado: 4800 muestras comparadas con el filtro de 64 coeficientes calculado directo, 0 errores.
En cada instante de símbolo la salida vale justo ±0.5.
