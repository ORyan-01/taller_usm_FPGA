//! @title Top level transmisor - Testbench
//! @file tb_top_tx.v
//! - Solo genera el reloj: el top no tiene otras entradas.
//! - Modelo de referencia: su propia PRBS9 y el filtro de 64 coeficientes completo
//!   (convolucion directa, sin separar en fases). Compara cada muestra de o_tx.
//! - Revisa ademas que en el instante de cada simbolo la salida valga justo +-0.5.
//! - Al final imprime PASS o FAIL.

`timescale 1ns/1ps

module tb_top_tx ();

  localparam [31:0] SEED      = 32'h0A0A_0505;
  localparam        NSIMB     = 600;           //! simbolos a revisar (mas que los 511 de la PRBS9)
  localparam        NMUESTRAS = 8 * NSIMB;     //! 8 muestras por simbolo

  reg                tb_clk = 1'b0;
  wire signed [11:0] tb_tx;

  //! Instancia del top: solo entra el reloj
  top_tx
    #(
      .SEED (SEED)
    )
    u_top_tx (
      .o_tx (tb_tx),
      .clk  (tb_clk)
    );

  // Clock: 100 MHz
  always #5 tb_clk = ~tb_clk;

  // ---------------- modelo de referencia ----------------
  wire [64*12-1:0] coef_ref;                   // otra copia de los coeficientes
  set_Coeff u_coef_ref (
    .o_coeff (coef_ref)
  );

  integer     a [0:NSIMB-1];                   // simbolos en S(8,7): +64 = +0.5, -64 = -0.5
  reg   [8:0] lfsr;
  integer     i;

  //! Muestra k de la salida: y[k] = suma de h[j]*u[k-j], donde u son los simbolos
  //! con 7 ceros entre cada uno (8 muestras por simbolo)
  function integer y_ref;
    input integer k;
    integer j, t, acc;
    begin
      acc = 0;
      for (j = 0; j < 64; j = j + 1) begin
        t = k - j;
        if (t >= 0 && t % 8 == 0)
          acc = acc + $signed(coef_ref[j*12 +: 12]) * a[t/8];
      end
      acc = acc >>> 7;                         // trunca a S(12,10)
      if (acc >  2047) acc =  2047;            // satura
      if (acc < -2048) acc = -2048;
      y_ref = acc;
    end
  endfunction

  // ---------------- comparacion ----------------
  integer ciclo = 0, k, esperado;
  integer revisadas = 0, errores = 0, centros = 0, centros_ok = 0;

  always @(negedge tb_clk) begin
    if (!u_top_tx.srst) begin                      // ya paso el reset de encendido
      if (ciclo >= 1 && ciclo <= NMUESTRAS) begin  // o_tx sale 1 ciclo despues del mux
        k        = ciclo - 1;
        esperado = y_ref(k);
        if (tb_tx !== esperado) begin
          errores = errores + 1;
          if (errores <= 10)
            $display("ERROR muestra %0d: hardware %0d, referencia %0d", k, tb_tx, esperado);
        end
        if (k >= 32 && k % 8 == 0) begin           // instante de simbolo (fase 0)
          centros = centros + 1;
          if (tb_tx == 512 || tb_tx == -512) centros_ok = centros_ok + 1;
        end
        if (k >= 32 && k < 48)
          $display("k=%0d  fase=%0d  salida=%0d  (%f)", k, k % 8, tb_tx, $itor(tb_tx) / 1024.0);
        revisadas = revisadas + 1;
      end
      ciclo = ciclo + 1;
    end
  end

  // ---------------- estimulo y resumen ----------------
  initial begin
    $display("");
    $display("Simulation Started");
    lfsr = SEED[8:0];                              // la misma PRBS9, calculada aparte
    for (i = 0; i < NSIMB; i = i + 1) begin
      a[i] = lfsr[8] ? -64 : 64;                   // bit 1 -> -0.5, bit 0 -> +0.5
      lfsr = {lfsr[7:0], lfsr[8] ^ lfsr[4]};
    end

    #50000;                                        // 4800 muestras de 10 ns, mas el reset

    $display("Muestras revisadas: %0d, errores: %0d", revisadas, errores);
    $display("Instantes de simbolo: %0d de %0d valen justo +-0.5", centros_ok, centros);
    if (revisadas == NMUESTRAS && errores == 0 && centros > 0 && centros_ok == centros)
      $display("PASS");
    else
      $display("FAIL");
    $display("Simulation Finished");
    $display("");
    $finish;
  end

endmodule
