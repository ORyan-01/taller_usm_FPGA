//! @title Coeficientes FIR - set_Coeff
//! @file set_Coeff.v
//! - Banco de 64 coeficientes de 12 bits (los mismos valores hex del original).
//! - Formato S(12,10): 12 bits, 10 fraccionarios -> 12'h400 = 1.0
//!   Rango representable: [-2, +1.9990234375]
//! - Los 64 coeficientes salen juntos en un bus de 64*12 = 768 bits:
//!   o_coeff[k*12 +: 12] es el coeficiente k.
//!   (Un puerto que es un arreglo, como coeff_m [0:63], es SystemVerilog, no Verilog.)

`timescale 1ns/1ps

module set_Coeff
  #(
    parameter NB_COEFF  = 12,   //! NB of Coefficients
    parameter NBF_COEFF = 10,   //! NBF of Coefficients
    parameter NTAPS     = 64    //! Cantidad de coeficientes
  )
  (
    output [NTAPS*NB_COEFF-1:0] o_coeff //! Los 64 coeficientes, uno al lado del otro
  );

  wire signed [NB_COEFF-1:0] coeff_m [0:NTAPS-1];

  // S(12,10)
  assign coeff_m[ 0] = 12'h000; // 0.0
  assign coeff_m[ 1] = 12'hFDF; // -0.0322265625
  assign coeff_m[ 2] = 12'hFC2; // -0.060546875
  assign coeff_m[ 3] = 12'hFAC; // -0.08203125
  assign coeff_m[ 4] = 12'hFA2; // -0.091796875
  assign coeff_m[ 5] = 12'hFA6; // -0.087890625
  assign coeff_m[ 6] = 12'hFB9; // -0.0693359375
  assign coeff_m[ 7] = 12'hFD8; // -0.0390625
  assign coeff_m[ 8] = 12'h000; // 0.0
  assign coeff_m[ 9] = 12'h02B; // 0.0419921875
  assign coeff_m[10] = 12'h053; // 0.0810546875
  assign coeff_m[11] = 12'h072; // 0.111328125
  assign coeff_m[12] = 12'h082; // 0.126953125
  assign coeff_m[13] = 12'h07E; // 0.123046875
  assign coeff_m[14] = 12'h066; // 0.099609375
  assign coeff_m[15] = 12'h03A; // 0.056640625
  assign coeff_m[16] = 12'h000; // 0.0
  assign coeff_m[17] = 12'hFBD; // -0.0654296875
  assign coeff_m[18] = 12'hF7C; // -0.12890625
  assign coeff_m[19] = 12'hF46; // -0.181640625
  assign coeff_m[20] = 12'hF26; // -0.212890625
  assign coeff_m[21] = 12'hF24; // -0.21484375
  assign coeff_m[22] = 12'hF47; // -0.1806640625
  assign coeff_m[23] = 12'hF91; // -0.1083984375
  assign coeff_m[24] = 12'h000; // 0.0
  assign coeff_m[25] = 12'h08E; // 0.138671875
  assign coeff_m[26] = 12'h133; // 0.2998046875
  assign coeff_m[27] = 12'h1E1; // 0.4697265625
  assign coeff_m[28] = 12'h28B; // 0.6357421875
  assign coeff_m[29] = 12'h323; // 0.7841796875
  assign coeff_m[30] = 12'h399; // 0.8994140625
  assign coeff_m[31] = 12'h3E5; // 0.9736328125
  assign coeff_m[32] = 12'h400; // 1.0
  assign coeff_m[33] = 12'h3E5; // 0.9736328125
  assign coeff_m[34] = 12'h399; // 0.8994140625
  assign coeff_m[35] = 12'h323; // 0.7841796875
  assign coeff_m[36] = 12'h28B; // 0.6357421875
  assign coeff_m[37] = 12'h1E1; // 0.4697265625
  assign coeff_m[38] = 12'h133; // 0.2998046875
  assign coeff_m[39] = 12'h08E; // 0.138671875
  assign coeff_m[40] = 12'h000; // 0.0
  assign coeff_m[41] = 12'hF91; // -0.1083984375
  assign coeff_m[42] = 12'hF47; // -0.1806640625
  assign coeff_m[43] = 12'hF24; // -0.21484375
  assign coeff_m[44] = 12'hF26; // -0.212890625
  assign coeff_m[45] = 12'hF46; // -0.181640625
  assign coeff_m[46] = 12'hF7C; // -0.12890625
  assign coeff_m[47] = 12'hFBD; // -0.0654296875
  assign coeff_m[48] = 12'h000; // 0.0
  assign coeff_m[49] = 12'h03A; // 0.056640625
  assign coeff_m[50] = 12'h066; // 0.099609375
  assign coeff_m[51] = 12'h07E; // 0.123046875
  assign coeff_m[52] = 12'h082; // 0.126953125
  assign coeff_m[53] = 12'h072; // 0.111328125
  assign coeff_m[54] = 12'h053; // 0.0810546875
  assign coeff_m[55] = 12'h02B; // 0.0419921875
  assign coeff_m[56] = 12'h000; // 0.0
  assign coeff_m[57] = 12'hFD8; // -0.0390625
  assign coeff_m[58] = 12'hFB9; // -0.0693359375
  assign coeff_m[59] = 12'hFA6; // -0.087890625
  assign coeff_m[60] = 12'hFA2; // -0.091796875
  assign coeff_m[61] = 12'hFAC; // -0.08203125
  assign coeff_m[62] = 12'hFC2; // -0.060546875
  assign coeff_m[63] = 12'hFDF; // -0.0322265625

  //! Junta los 64 coeficientes en el bus de salida
  genvar k;
  generate
    for (k = 0; k < NTAPS; k = k + 1) begin : g_bus
      assign o_coeff[k*NB_COEFF +: NB_COEFF] = coeff_m[k];
    end
  endgenerate

endmodule
