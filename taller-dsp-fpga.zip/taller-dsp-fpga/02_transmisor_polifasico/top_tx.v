//! @title Top level - Transmisor polifasico
//! @file top_tx.v
//! - Unica entrada: el reloj. El reset se genera adentro al encender la FPGA.
//! - PRBS9 -> BPSK (+-0.5) -> 8 filtros de transmision (uno por fase) -> mux 8 a 1.
//! - Cada simbolo dura 8 ciclos y la salida entrega 8 muestras por simbolo.
//! - Los 64 coeficientes de set_Coeff se reparten asi:
//!   el filtro de la fase p usa h[p], h[p+8], h[p+16], ..., h[p+56].

`timescale 1ns/1ps

module top_tx
  #(
    parameter [31:0] SEED = 32'h0A0A_0505   //! semilla de la PRBS9
  )
  (
    output reg signed [11:0] o_tx,   //! senal transmitida S(12,10): salida del mux
    input                    clk     //! reloj
  );

  localparam NB_COEFF = 12;

  // ---- 1) reset de encendido: no hay pin de reset ----
  reg  [3:0] cnt_rst = 4'd0;              // la FPGA arranca con este valor
  wire       srst    = ~&cnt_rst;         // 1 durante los primeros 15 ciclos
  always @(posedge clk)
    if (srst) cnt_rst <= cnt_rst + 4'd1;

  // ---- 2) contador de fase: 0, 1, ..., 7, 0, 1, ... ----
  reg [2:0] fase;
  always @(posedge clk) begin
    if (srst) fase <= 3'd0;
    else      fase <= fase + 3'd1;        // con 3 bits, despues de 7 vuelve solo a 0
  end

  wire en_simbolo = (fase == 3'd7);       // 1 ciclo de cada 8: entra un simbolo nuevo

  // ---- 3) PRBS9 y BPSK ----
  localparam signed [7:0] MAS_MEDIO   = 8'b0100_0000;  // +0.5 en S(8,7)
  localparam signed [7:0] MENOS_MEDIO = 8'b1100_0000;  // -0.5 en S(8,7)

  wire bit_prbs;
  prbs9 #(.seed(SEED)) u_prbs9 (
    .CLK    (clk),
    .rst    (srst),
    .enb    (en_simbolo),
    .salida (bit_prbs)
  );

  wire signed [7:0] simbolo = bit_prbs ? MENOS_MEDIO : MAS_MEDIO;   // 0 -> +0.5, 1 -> -0.5

  // ---- 4) banco de 64 coeficientes ----
  wire [64*NB_COEFF-1:0] coef_bus;
  set_Coeff u_coef (
    .o_coeff (coef_bus)
  );

  // ---- 5) 8 filtros de transmision, uno por fase ----
  wire signed [11:0] rama [0:7];          // salida de cada filtro

  genvar p, m;
  generate
    for (p = 0; p < 8; p = p + 1) begin : g_fase
      wire [8*NB_COEFF-1:0] coef_fase;    // los 8 coeficientes de esta fase
      for (m = 0; m < 8; m = m + 1) begin : g_coef
        assign coef_fase[m*NB_COEFF +: NB_COEFF] = coef_bus[(8*m + p)*NB_COEFF +: NB_COEFF];  // h[8m+p]
      end

      filtro_fir8
        #(
          .NB_INPUT   (8),
          .NBF_INPUT  (7),
          .NB_OUTPUT  (12),
          .NBF_OUTPUT (10),
          .NB_COEFF   (12),
          .NBF_COEFF  (10)
        )
        u_filtro (
          .o_os_data (rama[p]),
          .i_is_data (simbolo),
          .i_coeff   (coef_fase),
          .i_srst    (srst),
          .i_en      (en_simbolo),
          .clk       (clk)
        );
    end
  endgenerate

  // ---- 6) mux 8 a 1: en la fase p sale el filtro p (registrado) ----
  always @(posedge clk) begin
    if (srst)
      o_tx <= 12'sd0;
    else
      case (fase)
        3'd0: o_tx <= rama[0];
        3'd1: o_tx <= rama[1];
        3'd2: o_tx <= rama[2];
        3'd3: o_tx <= rama[3];
        3'd4: o_tx <= rama[4];
        3'd5: o_tx <= rama[5];
        3'd6: o_tx <= rama[6];
        3'd7: o_tx <= rama[7];
      endcase
  end

endmodule
